import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Ranking {
	//Class to use methods that return arrayLists with the rankings, connecting the database
	Ranking(){
	}
	public ArrayList <String[]> globalRanking() {
		//Method that returns the 5 players with the most points
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
		String usuario = "root";
		String pass = "root";
		ArrayList<String[]> ranking = new ArrayList<String[]>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
			String query = "select players.player_name as \"player name\",ranking.total_points as \"total points\",warriors.warrior_name as \"warrior\" \n"
					+ "from ranking\n"
					+ "inner join players on players.player_id = ranking.player_id\n"
					+ "inner join warriors on warriors.warrior_id = ranking.warrior_id\n"
					+ "order by ranking.total_points desc limit 5;";

			Statement stmnt = conn.createStatement();
			
			ResultSet rs = stmnt.executeQuery(query);
			
			while(rs.next()) {
				String [] row = new String[3];
				row[0] = rs.getString(1);
				row[1] = rs.getInt(2)+"";
				row[2] = rs.getString(3);
				ranking.add(row);
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no se ha cargado correctamente!!");
		} catch (SQLException e) {
			System.out.println("Conexión no creada correctamente!!");
		}
		return ranking;
	}
	public ArrayList <String[]> defeatedEnemies(){
		//Method that returns the 5 players with the most defeated enemies
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
		String usuario = "root";
		String pass = "root";
		ArrayList<String[]> ranking = new ArrayList<String[]>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
			String query = "select players.player_name,count(battle.battle_id) as \"defeated enemies\" from battle\n"
					+ "inner join players on players.player_id = battle.player_id\n"
					+ "where  battle.battle_points > 0\n"
					+ "group by battle.player_id\n"
					+ "order by count(battle.battle_id) desc limit 5;";

			Statement stmnt = conn.createStatement();
			
			ResultSet rs = stmnt.executeQuery(query);
			
			while(rs.next()) {
				String [] row = new String[2];
				row[0] = rs.getString(1);
				row[1] = rs.getInt(2)+"";
				ranking.add(row);
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no se ha cargado correctamente!!");
		} catch (SQLException e) {
			System.out.println("Conexión no creada correctamente!!");
		}
		return ranking;
	}
	public ArrayList <String[]> moreUsedWarriors(){
		//Method that returns the 5 most used warriors
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
		String usuario = "root";
		String pass = "root";
		ArrayList<String[]> ranking = new ArrayList<String[]>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
			String query = "select warriors.warrior_name, count(ranking.warrior_id) from ranking\n"
					+ "inner join warriors on ranking.warrior_id = warriors.warrior_id\n"
					+ "group by ranking.warrior_id\n"
					+ "order by count(ranking.warrior_id) desc limit 5;";

			Statement stmnt = conn.createStatement();
			
			ResultSet rs = stmnt.executeQuery(query);
			
			while(rs.next()) {
				String [] row = new String[2];
				row[0] = rs.getString(1);
				row[1] = rs.getInt(2)+"";
				ranking.add(row);
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no se ha cargado correctamente!!");
		} catch (SQLException e) {
			System.out.println("Conexión no creada correctamente!!");
		}
		return ranking;
	}
	public ArrayList <String[]> moreUsedWeapons(){
		//Method that returns the 5 most used weapons
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
		String usuario = "root";
		String pass = "root";
		ArrayList<String[]> ranking = new ArrayList<String[]>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
			String query = "select weapons.weapon_name, count(battle.warrior_weapon_id) from battle\n"
					+ "inner join weapons on battle.warrior_weapon_id = weapons.weapon_id\n"
					+ "group by battle.warrior_weapon_id\n"
					+ "order by count(battle.warrior_weapon_id) desc limit 5;";

			Statement stmnt = conn.createStatement();
			
			ResultSet rs = stmnt.executeQuery(query);
			
			while(rs.next()) {
				String [] row = new String[2];
				row[0] = rs.getString(1);
				row[1] = rs.getInt(2)+"";
				ranking.add(row);
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no se ha cargado correctamente!!");
		} catch (SQLException e) {
			System.out.println("Conexión no creada correctamente!!");
		}
		return ranking;
	}

}