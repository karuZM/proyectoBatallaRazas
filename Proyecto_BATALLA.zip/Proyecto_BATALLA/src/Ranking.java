import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Ranking {
	Ranking(){
	}
	public ArrayList <String[]> globalRanking() {
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
		String usuario = "root";
		String pass = "root";
		ArrayList<String[]> ranking = new ArrayList<String[]>();
		try {
			//Cargar driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Crear conexion BBDD
			java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
			String query = "select players.player_name as \"player name\",ranking.total_points as \"total points\",warriors.warrior_name as \"warrior\" \n"
					+ "from ranking\n"
					+ "inner join players on players.player_id = ranking.player_id\n"
					+ "inner join warriors on warriors.warrior_id = ranking.warrior_id\n"
					+ "order by ranking.total_points desc limit 5;";

			//Instanciar objeto de la clase Consulta
			Statement stmnt = conn.createStatement();
			
			//Ejecutar la consulta
			ResultSet rs = stmnt.executeQuery(query);
			
			while(rs.next()) {
				String [] row = new String[3];
				row[0] = rs.getString(1);
				row[1] = rs.getInt(2)+"";
				row[2] = rs.getString(3);
				ranking.add(row);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver no se ha cargado correctamente!!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Conexión no creada correctamente!!");
		}
		return ranking;
	}
	public ArrayList <String[]> defeatedEnemies(){
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
		String usuario = "root";
		String pass = "root";
		ArrayList<String[]> ranking = new ArrayList<String[]>();
		try {
			//Cargar driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Crear conexion BBDD
			java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
			String query = "select players.player_name,count(battle.battle_id) as \"defeated enemies\" from battle\n"
					+ "inner join players on players.player_id = battle.player_id\n"
					+ "where  battle.battle_points > 0\n"
					+ "group by battle.player_id\n"
					+ "order by count(battle.battle_id) desc limit 5;";

			//Instanciar objeto de la clase Consulta
			Statement stmnt = conn.createStatement();
			
			//Ejecutar la consulta
			ResultSet rs = stmnt.executeQuery(query);
			
			while(rs.next()) {
				String [] row = new String[2];
				row[0] = rs.getString(1);
				row[1] = rs.getInt(2)+"";
				ranking.add(row);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver no se ha cargado correctamente!!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Conexión no creada correctamente!!");
		}
		return ranking;
	}
	public static void main(String[] args) {
		Ranking r = new Ranking();
		ArrayList<String[]> ed = r.defeatedEnemies();
		for (String[] fila : ed) {
			System.out.println(fila[0]+" - "+fila[1]);
		}
	}

}
