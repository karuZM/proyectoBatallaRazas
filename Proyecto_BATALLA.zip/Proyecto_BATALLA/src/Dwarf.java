
public class Dwarf extends Warrior{

	public Dwarf() {
		super();
	}

	public Dwarf(int id, String name, String url) {
		super(id, name, 60, 6, 5, 6, 3, url, null);
	}
	

}
