import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RankingUser {
	private int id;
	private String username;
	private int totalPoints;
	RankingUser(){}
	RankingUser(String username){
		this.username = username;
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            Statement stmnt = conn.createStatement();

            String query = "select max(player_id) from players";
            ResultSet rs = stmnt.executeQuery(query);
            rs.next();
            this.id = rs.getInt(1)+1;
            
        } catch (ClassNotFoundException e) {
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
        this.totalPoints = 0;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getTotalPoints() {
		return totalPoints;
	}
	public void setTotalPoints(int totalPoints) {
		this.totalPoints = totalPoints;
	}
	

}
