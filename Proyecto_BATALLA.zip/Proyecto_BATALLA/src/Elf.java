
public class Elf extends Warrior{

	public Elf() {
		super();
	}

	public Elf(int id, String name, String url) {
		super(id, name, 40, 4, 7, 7, 2, url, null);
	}
	

}
