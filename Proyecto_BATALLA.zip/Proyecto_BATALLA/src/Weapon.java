import java.util.ArrayList;
import java.util.Iterator;

public class Weapon {
	private int id,strength, speed;
	private String name, url;
	private ArrayList<String> clases = new ArrayList<String>();

	public Weapon() {
		super();
	}

	public Weapon(int id, String name, int strength, int speed, String url) {
		super();
		this.id = id;
		this.name = name;
		this.strength = strength;
		this.speed = speed;
		this.url = url;
	}

	public Weapon(int id, String name, int strength, int speed, String url,String clases) {
		super();
		String[] arrayClases = clases.split(",");
		for (int i = 0; i < arrayClases.length; i++) {
			this.clases.add(arrayClases[i]);
		}
		
		this.id = id;
		this.name = name;
		this.strength = strength;
		this.speed = speed;
		this.url = url;
	}

	
	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public ArrayList<String> getClases() {
		return clases;
	}
	
}
