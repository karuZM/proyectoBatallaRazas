
public class Weapon {
	private int strength, speed;

	public Weapon() {
		super();
	}

	public Weapon(int strength, int speed) {
		super();
		this.strength = strength;
		this.speed = speed;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
}

class Dagger extends Weapon{
	public Dagger() {
		super(0,3);
	}
}
class Sword extends Weapon{
	public Sword() {
		super(1,1);
	}
}
class Hatchet extends Weapon{
	public Hatchet() {
		super(3,0);
	}
}
class DoubleSwords extends Weapon{
	public DoubleSwords() {
		super(2,2);
	}
}
class Scimitar extends Weapon{
	public Scimitar() {
		super(1,2);
	}
}
class Bow extends Weapon{
	public Bow() {
		super(1,5);
	}
}
class Katana extends Weapon{
	public Katana() {
		super(2,3);
	}
}
class Poniard extends Weapon{
	public Poniard() {
		super(0,4);
	}
}
class TwoHandedHatchet extends Weapon{
	public TwoHandedHatchet() {
		super(5,0);
	}
}






