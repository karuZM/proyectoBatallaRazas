
public class Human extends Warrior{

	public Human() {
		super();
	}

	public Human(int id, String name, String url) {
		super(id, name, 50, 6, 5, 6, 3, url,null);
	}
	

}
