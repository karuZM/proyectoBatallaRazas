import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class Fight {

	public static void main(String[] args) {
		new Window0();
		//new Window();
		//new WindowCharacters();
		//new GlobalRanking();
		//new DefeatedEnemies();
	}
}
class Window0 extends JFrame{
	public String name;
	private JPanel up,down,left,right,center,mid,buttons,titleuser,usernamep;
	private JButton b1,b2;
	private JTextField username;
	private JLabel title,user;
	public Window0(){
		setBackground(Color.BLACK);
		up = new JPanel();
		left = new JPanel();
		right = new JPanel();
		down = new JPanel();
		center = new JPanel();
		up.setBackground(Color.black);
		right.setBackground(Color.black);
		left.setBackground(Color.black);
		down.setBackground(Color.black);
		center.setBackground(Color.black);
		up.setPreferredSize(new Dimension(100,300));
		left.setPreferredSize(new Dimension(50,50));
		right.setPreferredSize(new Dimension(50,50));
		down.setPreferredSize(new Dimension(50,50));
		center.setPreferredSize(new Dimension(50,50));
		add(up,BorderLayout.NORTH);
		add(left,BorderLayout.WEST);
		add(right,BorderLayout.EAST);
		add(down,BorderLayout.SOUTH);
		add(center,BorderLayout.CENTER);
		titleuser = new JPanel();
		titleuser.setBackground(Color.black);
		titleuser.setLayout(new BorderLayout());
		title = new JLabel("Battle of Races", SwingConstants.CENTER);
		title.setFont(new Font("arial", Font.BOLD,70));
		title.setForeground(Color.white);
		user = new JLabel("Enter your username:");
		user.setForeground(Color.white);
		buttons = new JPanel();
		buttons.setBackground(Color.BLACK);
		b1 = new JButton("Jugar");
		b2 = new JButton("Salir");
		usernamep = new JPanel();
		usernamep.setLayout(new BorderLayout());
		usernamep.setBackground(Color.BLACK);
		username = new JTextField("Your name",40);
		username.setForeground(Color.GRAY);
		mid = new JPanel();
		mid.setPreferredSize(new Dimension(60,60));
		mid.setBackground(Color.black);
		
		up.add(titleuser,BorderLayout.NORTH);
		center.add(buttons,BorderLayout.SOUTH);
		titleuser.add(mid,BorderLayout.CENTER);
		titleuser.add(title,BorderLayout.NORTH);
		titleuser.add(usernamep,BorderLayout.SOUTH);
		
		usernamep.add(user,BorderLayout.WEST);
		usernamep.add(username,BorderLayout.EAST);
		buttons.add(b1);
		buttons.add(b2);
		
		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String name = username.getText();
				if (name.equalsIgnoreCase("")) {
						
				}else {
					new Window();
				}
				
			}
			
		});
		b2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
			
		});
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(200,100,900,500);
		this.setVisible(true);
	}
	
}
class Window extends JFrame implements ActionListener{
	private WarriorContainer warriors = new WarriorContainer();
	private Warrior w2 = warriors.randomWarrior();
	private Ch1 ch1 = new Ch1();
	private JPanel choose,character1,stats1,stats2,habilities1,habilities2,character2,fight_buttons,fight;
	private JButton ch_character, ch_weapon, ranking, fightButton, clearConsole;
	private JProgressBar health1, health2,power1,power2,agility1,agility2,speed1,speed2,defense1,defense2;
	private JLabel img1,img2,name1,name2,weapon1,weapon2,power1_,power2_,agility1_,agility2_,speed1_,speed2_,defense1_,defense2_;
	private JTextArea console;
	WeaponContainer wepCont_w2 = new WeaponContainer();
	Window(){
		w2.setWeapon(wepCont_w2.getRandomWeapon(w2));
		choose = new JPanel();
		ch_character = new JButton("Choose Character");
		ch_character.addActionListener(this);
		ch_weapon = new JButton("Choose Weapon");
		ranking = new JButton("Ranking");
		choose.add(ch_character);
		choose.add(ch_weapon);
		choose.add(ranking);
		
		/*
		if (!(ch1==null)) {
		character1 = new JPanel();
		character1.setLayout(new BorderLayout());
		health1 = new JProgressBar(0,ch1.getHealth());
		health1.setValue(ch1.getHealth());
		health1.setStringPainted(true);
		health1.setForeground(Color.GREEN);
		
		img1 = new JLabel();
		
		stats1 = new JPanel();
		stats1.setLayout(new BorderLayout());
		name1 = new JLabel(ch1.getName(), SwingConstants.CENTER);
		weapon1 = new JLabel();
		
		habilities1 = new JPanel();
		habilities1.setLayout(new GridLayout(4,2));
		power1_ = new JLabel("Power");
		power1 = new JProgressBar(0,11);
		power1.setValue(ch1.getStrength());
		power1.setForeground(Color.BLUE);
		
		agility1_ = new JLabel("Agility");
		agility1 = new JProgressBar(0,7);
		agility1.setValue(ch1.getAgility());
		agility1.setForeground(Color.RED);
		
		speed1_ = new JLabel("Speed");
		speed1 = new JProgressBar(0,12);
		speed1.setValue(ch1.getSpeed());
		speed1.setForeground(Color.YELLOW);
		
		defense1_ = new JLabel("Defense");
		defense1 = new JProgressBar(0,4);
		defense1.setValue(ch1.getDefense());
		defense1.setForeground(Color.PINK);
		
		habilities1.add(power1_);
		habilities1.add(power1);
		habilities1.add(agility1_);
		habilities1.add(agility1);
		habilities1.add(speed1_);
		habilities1.add(speed1);
		habilities1.add(defense1_);
		habilities1.add(defense1);
		
		stats1.add(name1,BorderLayout.NORTH);
		stats1.add(habilities1,BorderLayout.EAST);
		stats1.add(weapon1, BorderLayout.WEST);
		
		character1.add(health1,BorderLayout.NORTH);
		character1.add(img1, BorderLayout.CENTER);
		character1.add(stats1,BorderLayout.SOUTH);
		this.add(character1,BorderLayout.WEST);

		}*/
		
		character2 = new JPanel();
		character2.setLayout(new BorderLayout());
		health2 = new JProgressBar(0,w2.getHealth());
		health2.setValue(w2.getHealth());
		health2.setStringPainted(true);
		health2.setForeground(Color.GREEN);
		img2 = new JLabel();
		Toolkit mipantalla = Toolkit.getDefaultToolkit();
		Image img;
		Image dimg;
		ImageIcon icon;
		img = mipantalla.getImage(w2.getUrl());
		dimg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH);
		icon = new ImageIcon(dimg);
		img2.setIcon(icon);
		stats2 = new JPanel();
		stats2.setLayout(new BorderLayout());
		name2 = new JLabel(w2.getName(), SwingConstants.CENTER);
		weapon2 = new JLabel();
		img = mipantalla.getImage(w2.getWeapon().getUrl());
		dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		icon = new ImageIcon(dimg);
		weapon2.setIcon(icon);
		
		habilities2 = new JPanel();
		habilities2.setLayout(new GridLayout(4,2));
		power2_ = new JLabel("Power");
		power2 = new JProgressBar(0,11);
		power2.setValue(w2.getStrength());
		power2.setForeground(Color.BLUE);
		
		agility2_ = new JLabel("Agility");
		agility2 = new JProgressBar(0,7);
		agility2.setValue(w2.getAgility());
		agility2.setForeground(Color.RED);
		
		speed2_ = new JLabel("Speed");
		speed2 = new JProgressBar(0,12);
		speed2.setValue(w2.getSpeed());
		speed2.setForeground(Color.YELLOW);
		
		defense2_ = new JLabel("Defense");
		defense2 = new JProgressBar(0,4);
		defense2.setValue(w2.getDefense());
		defense2.setForeground(Color.PINK);

		
		habilities2.add(power2_);
		habilities2.add(power2);
		habilities2.add(agility2_);
		habilities2.add(agility2);
		habilities2.add(speed2_);
		habilities2.add(speed2);
		habilities2.add(defense2_);
		habilities2.add(defense2);
		
		stats2.add(name2,BorderLayout.NORTH);
		stats2.add(habilities2,BorderLayout.EAST);
		
		stats2.add(weapon2, BorderLayout.WEST);
		
		character2.add(health2,BorderLayout.NORTH);
		character2.add(img2, BorderLayout.CENTER);
		character2.add(stats2,BorderLayout.SOUTH);

		fight = new JPanel();
		fight_buttons = new JPanel();
		fight.setLayout(new BorderLayout());
		fightButton = new JButton("Fight");
		clearConsole = new JButton("Clear Console");
		fight_buttons.add(fightButton);
		fight_buttons.add(clearConsole);
		console = new JTextArea(10,800);
		console.setEditable(false);
		
		fight.add(fight_buttons, BorderLayout.NORTH);
		fight.add(console,BorderLayout.SOUTH);
		
		this.add(choose,BorderLayout.NORTH);
		this.add(ch1,BorderLayout.WEST);
		this.add(character2,BorderLayout.EAST);
		this.add(fight,BorderLayout.SOUTH);
		
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(200,300,800,800);
		this.setVisible(true);

	}
	public void setCh1(Ch1 ch1) {
		this.ch1 = ch1;
	}
	class Ch1 extends JPanel{
		private Warrior w = warriors.randomWarrior();
		private JPanel habilities1 ,stats1;
		private JProgressBar health1,power1,agility1,speed1,defense1;
		JLabel etiquetaWarrior;
		Ch1(){
			//w.setWeapon(new Weapon(3, "ee", 3, 4, "ImagenesProjecto/Armas/Dagger.jpg"));
			wepCont_w2 = new WeaponContainer();
			w.setWeapon(wepCont_w2.getRandomWeapon(w));
			this.setLayout(new BorderLayout());
			health1 = new JProgressBar(0,w.getHealth());
			health1.setValue(w.getHealth());
			health1.setStringPainted(true);
			health1.setForeground(Color.GREEN);
			
			img1 = new JLabel();
			etiquetaWarrior = new JLabel();
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			Image dimg;
			ImageIcon icon;
			img = mipantalla.getImage(w.getUrl());
//			dimg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH);
//			icon = new ImageIcon(dimg);
//			img1.setIcon(icon);
			etiquetaWarrior.setIcon(new ImageIcon(img.getScaledInstance(300, 300, Image.SCALE_SMOOTH)));


			
			stats1 = new JPanel();
			stats1.setLayout(new BorderLayout());
			name1 = new JLabel(w.getName(), SwingConstants.CENTER);
			weapon1 = new JLabel();
			img = mipantalla.getImage(w.getWeapon().getUrl());
			dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			weapon1.setIcon(icon);
			
			habilities1 = new JPanel();
			habilities1.setLayout(new GridLayout(4,2));
			power1_ = new JLabel("Power");
			power1 = new JProgressBar(0,11);
			power1.setValue(w.getStrength());
			power1.setForeground(Color.BLUE);
			
			agility1_ = new JLabel("Agility");
			agility1 = new JProgressBar(0,7);
			agility1.setValue(w.getAgility());
			agility1.setForeground(Color.RED);
			
			speed1_ = new JLabel("Speed");
			speed1 = new JProgressBar(0,12);
			speed1.setValue(w.getSpeed());
			speed1.setForeground(Color.YELLOW);
			
			defense1_ = new JLabel("Defense");
			defense1 = new JProgressBar(0,4);
			defense1.setValue(w.getDefense());
			defense1.setForeground(Color.PINK);
			
			habilities1.add(power1_);
			habilities1.add(power1);
			habilities1.add(agility1_);
			habilities1.add(agility1);
			habilities1.add(speed1_);
			habilities1.add(speed1);
			habilities1.add(defense1_);
			habilities1.add(defense1);
			
			stats1.add(name1,BorderLayout.NORTH);
			stats1.add(habilities1,BorderLayout.EAST);
			stats1.add(weapon1, BorderLayout.WEST);
			
			this.add(health1,BorderLayout.NORTH);
			this.add(etiquetaWarrior, BorderLayout.CENTER);
			this.add(stats1,BorderLayout.SOUTH);
			
			this.setVisible(true);
			
		}
		public void setWarrior(Warrior w) {
			this.w = w;
			
			Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			img = mipantalla.getImage(w.getUrl());
//			dimg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH);
//			icon = new ImageIcon(dimg);
//			img1.setIcon(icon);
			etiquetaWarrior.setIcon(new ImageIcon(img.getScaledInstance(300, 300, Image.SCALE_SMOOTH)));
			w.setWeapon(wepCont_w2.getRandomWeapon(w));
			name1.setText(w.getName());
			setStats();
			
			// poner arma a null o poner una aleatoria
			
		}
		public Warrior getWarrior() {
			return w;
			
		}
		public void setStats() {
			if (w.getWeapon()!=null) {
				speed1.setValue(w.getSpeed()+w.getWeapon().getSpeed());
				power1.setValue(w.getStrength()+w.getWeapon().getStrength());
			}else {
				power1.setValue(w.getStrength());
				speed1.setValue(w.getSpeed());
			}
			
			agility1.setValue(w.getAgility());
			defense1.setValue(w.getDefense());
			
			
		}
		public void setWeapon() {
			
		}
		// metodo setear estados
		// speed1.setValue(w.getSpeed());
	
	}
	class WindowCharacters extends JFrame implements ActionListener{
		private JFrame myFrame;
		private WarriorContainer warriors;
		WindowCharacters(){
			myFrame = new JFrame();
			myFrame.setLayout(new GridLayout(3,3));
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			warriors = new WarriorContainer();
			Image img;
			Image dimg;
			ImageIcon icon;
			for (Warrior w : warriors.getWarriors()) {
				img = mipantalla.getImage(w.getUrl());
				dimg = img.getScaledInstance(100, 200, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				WarriorButton wb = new WarriorButton(icon,w.getId());
				if (w instanceof Human) {
					wb.setBackground(Color.CYAN);
				}
				if (w instanceof Elf) {
					wb.setBackground(Color.RED);
				}
				if (w instanceof Dwarf) {
					wb.setBackground(Color.YELLOW);
				}
				wb.addActionListener(this);
				myFrame.add(wb);
			}
			
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setBounds(200,300,800,800);
			myFrame.setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			int idWarrior = ((WarriorButton) (e.getSource())).getID();
			Warrior warriorSelected = warriors.getWarrior(idWarrior);
			ch1.setWarrior(warriorSelected);
			myFrame.dispose();
		}
	}
	/*
class ChooseWarrior implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		new WindowCharacters();
	}
	}*/
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==ch_character) {
			new WindowCharacters();
		}
	}
}


class WarriorButton extends JButton{
	private int id;

	public WarriorButton() {
		super();
	}

	public WarriorButton(ImageIcon i, int id) {
		super();
		this.setIcon(i);
		this.id = id;
	}
	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}
	
}


class GlobalRanking extends JFrame{
	private Ranking ranking = new Ranking();
	private ArrayList<String[]> globalRanking = ranking.globalRanking();
	private JPanel table;
	private JLabel title1,name,points,warrior;
	GlobalRanking(){
		title1 = new JLabel("GLOBAL RANKING", SwingConstants.CENTER);
		
		table = new JPanel();
		table.setLayout(new GridLayout(6,3));
		name = new JLabel("NAME");
		points = new JLabel("POINTS");
		warrior = new JLabel("WARRIOR");
		table.add(name);
		table.add(points);
		table.add(warrior);
		for (String[] row : globalRanking) {
			JLabel name1 = new JLabel(row[0]);
			JLabel points1 = new JLabel(row[1]);
			JLabel warrior1 = new JLabel(row[2]);
			table.add(name1);
			table.add(points1);
			table.add(warrior1);
		}
		this.add(title1, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);

		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(200,200,600,300);
		this.setVisible(true);
	}
}
class DefeatedEnemies extends JFrame{
	private Ranking ranking = new Ranking();
	private ArrayList<String[]> defeatedEnemies = ranking.defeatedEnemies();
	private JPanel table;
	private JLabel title,name,defEn;
	DefeatedEnemies(){
		title = new JLabel("DEFEATED ENEMIES RANKING",SwingConstants.CENTER);
		table = new JPanel();
		table.setLayout(new GridLayout(6,2));
		name = new JLabel("NAME");
		defEn = new JLabel("DEFEATED ENEMIES");
		table.add(name);
		table.add(defEn);
		for (String[] row : defeatedEnemies) {
			JLabel name1 = new JLabel(row[0]);
			JLabel defEn1 = new JLabel(row[1]);
			table.add(name1);
			table.add(defEn1);
		}
		this.add(title, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(200,200,400,300);
		this.setVisible(true);
	}

}
