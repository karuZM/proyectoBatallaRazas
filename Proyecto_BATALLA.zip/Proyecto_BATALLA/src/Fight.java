import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Fight {

	public static void main(String[] args) {
		new Window();
		//new WindowCharacters();

	}
}
class Window extends JFrame implements ActionListener{
	private WarriorContainer warriors = new WarriorContainer();
	private Warrior w2 = warriors.randomWarrior();
	private Ch1 ch1 = new Ch1();
	private JPanel choose,character1,stats1,stats2,habilities1,habilities2,character2,fight_buttons,fight;
	private JButton ch_character, ch_weapon, ranking, fightButton, clearConsole;
	private JProgressBar health1, health2,power1,power2,agility1,agility2,speed1,speed2,defense1,defense2;
	private JLabel img1,img2,name1,name2,weapon1,weapon2,power1_,power2_,agility1_,agility2_,speed1_,speed2_,defense1_,defense2_;
	private JTextArea console;
	Window(){
		choose = new JPanel();
		ch_character = new JButton("Choose Character");
		ch_character.addActionListener(this);
		ch_weapon = new JButton("Choose Weapon");
		ranking = new JButton("Ranking");
		choose.add(ch_character);
		choose.add(ch_weapon);
		choose.add(ranking);
		
		/*
		if (!(ch1==null)) {
		character1 = new JPanel();
		character1.setLayout(new BorderLayout());
		health1 = new JProgressBar(0,ch1.getHealth());
		health1.setValue(ch1.getHealth());
		health1.setStringPainted(true);
		health1.setForeground(Color.GREEN);
		
		img1 = new JLabel();
		
		stats1 = new JPanel();
		stats1.setLayout(new BorderLayout());
		name1 = new JLabel(ch1.getName(), SwingConstants.CENTER);
		weapon1 = new JLabel();
		
		habilities1 = new JPanel();
		habilities1.setLayout(new GridLayout(4,2));
		power1_ = new JLabel("Power");
		power1 = new JProgressBar(0,11);
		power1.setValue(ch1.getStrength());
		power1.setForeground(Color.BLUE);
		
		agility1_ = new JLabel("Agility");
		agility1 = new JProgressBar(0,7);
		agility1.setValue(ch1.getAgility());
		agility1.setForeground(Color.RED);
		
		speed1_ = new JLabel("Speed");
		speed1 = new JProgressBar(0,12);
		speed1.setValue(ch1.getSpeed());
		speed1.setForeground(Color.YELLOW);
		
		defense1_ = new JLabel("Defense");
		defense1 = new JProgressBar(0,4);
		defense1.setValue(ch1.getDefense());
		defense1.setForeground(Color.PINK);
		
		habilities1.add(power1_);
		habilities1.add(power1);
		habilities1.add(agility1_);
		habilities1.add(agility1);
		habilities1.add(speed1_);
		habilities1.add(speed1);
		habilities1.add(defense1_);
		habilities1.add(defense1);
		
		stats1.add(name1,BorderLayout.NORTH);
		stats1.add(habilities1,BorderLayout.EAST);
		stats1.add(weapon1, BorderLayout.WEST);
		
		character1.add(health1,BorderLayout.NORTH);
		character1.add(img1, BorderLayout.CENTER);
		character1.add(stats1,BorderLayout.SOUTH);
		this.add(character1,BorderLayout.WEST);

		}*/
		
		character2 = new JPanel();
		character2.setLayout(new BorderLayout());
		health2 = new JProgressBar(0,w2.getHealth());
		health2.setValue(w2.getHealth());
		health2.setStringPainted(true);
		health2.setForeground(Color.GREEN);
		img2 = new JLabel();
		Toolkit mipantalla = Toolkit.getDefaultToolkit();
		Image img;
		Image dimg;
		ImageIcon icon;
		img = mipantalla.getImage(w2.getUrl());
		dimg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH);
		icon = new ImageIcon(dimg);
		img2.setIcon(icon);
		stats2 = new JPanel();
		stats2.setLayout(new BorderLayout());
		name2 = new JLabel(w2.getName(), SwingConstants.CENTER);
		weapon2 = new JLabel();
		
		habilities2 = new JPanel();
		habilities2.setLayout(new GridLayout(4,2));
		power2_ = new JLabel("Power");
		power2 = new JProgressBar(0,11);
		power2.setValue(w2.getStrength());
		power2.setForeground(Color.BLUE);
		
		agility2_ = new JLabel("Agility");
		agility2 = new JProgressBar(0,7);
		agility2.setValue(w2.getAgility());
		agility2.setForeground(Color.RED);
		
		speed2_ = new JLabel("Speed");
		speed2 = new JProgressBar(0,12);
		speed2.setValue(w2.getSpeed());
		speed2.setForeground(Color.YELLOW);
		
		defense2_ = new JLabel("Defense");
		defense2 = new JProgressBar(0,4);
		defense2.setValue(w2.getDefense());
		defense2.setForeground(Color.PINK);

		
		habilities2.add(power2_);
		habilities2.add(power2);
		habilities2.add(agility2_);
		habilities2.add(agility2);
		habilities2.add(speed2_);
		habilities2.add(speed2);
		habilities2.add(defense2_);
		habilities2.add(defense2);
		
		stats2.add(name2,BorderLayout.NORTH);
		stats2.add(habilities2,BorderLayout.EAST);
		
		stats2.add(weapon2, BorderLayout.WEST);
		
		character2.add(health2,BorderLayout.NORTH);
		character2.add(img2, BorderLayout.CENTER);
		character2.add(stats2,BorderLayout.SOUTH);

		fight = new JPanel();
		fight_buttons = new JPanel();
		fight.setLayout(new BorderLayout());
		fightButton = new JButton("Fight");
		clearConsole = new JButton("Clear Console");
		fight_buttons.add(fightButton);
		fight_buttons.add(clearConsole);
		console = new JTextArea(10,800);
		console.setEditable(false);
		
		fight.add(fight_buttons, BorderLayout.NORTH);
		fight.add(console,BorderLayout.SOUTH);
		
		this.add(choose,BorderLayout.NORTH);
		this.add(ch1,BorderLayout.WEST);
		this.add(character2,BorderLayout.EAST);
		this.add(fight,BorderLayout.SOUTH);
		
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(200,300,800,800);
		this.setVisible(true);

	}
	public void setCh1(Ch1 ch1) {
		this.ch1 = ch1;
	}
	class Ch1 extends JPanel{
		private Warrior w = warriors.randomWarrior();
		private JPanel habilities1 ,stats1;
		private JProgressBar health1,power1,agility1,speed1,defense1;
		Ch1(){
			this.setLayout(new BorderLayout());
			health1 = new JProgressBar(0,w.getHealth());
			health1.setValue(w.getHealth());
			health1.setStringPainted(true);
			health1.setForeground(Color.GREEN);
			
			img1 = new JLabel();
			
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			Image dimg;
			ImageIcon icon;
			img = mipantalla.getImage(w.getUrl());
			dimg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			img1.setIcon(icon);


			
			stats1 = new JPanel();
			stats1.setLayout(new BorderLayout());
			name1 = new JLabel(w.getName(), SwingConstants.CENTER);
			weapon1 = new JLabel();
			
			habilities1 = new JPanel();
			habilities1.setLayout(new GridLayout(4,2));
			power1_ = new JLabel("Power");
			power1 = new JProgressBar(0,11);
			power1.setValue(w.getStrength());
			power1.setForeground(Color.BLUE);
			
			agility1_ = new JLabel("Agility");
			agility1 = new JProgressBar(0,7);
			agility1.setValue(w.getAgility());
			agility1.setForeground(Color.RED);
			
			speed1_ = new JLabel("Speed");
			speed1 = new JProgressBar(0,12);
			speed1.setValue(w.getSpeed());
			speed1.setForeground(Color.YELLOW);
			
			defense1_ = new JLabel("Defense");
			defense1 = new JProgressBar(0,4);
			defense1.setValue(w.getDefense());
			defense1.setForeground(Color.PINK);
			
			habilities1.add(power1_);
			habilities1.add(power1);
			habilities1.add(agility1_);
			habilities1.add(agility1);
			habilities1.add(speed1_);
			habilities1.add(speed1);
			habilities1.add(defense1_);
			habilities1.add(defense1);
			
			stats1.add(name1,BorderLayout.NORTH);
			stats1.add(habilities1,BorderLayout.EAST);
			stats1.add(weapon1, BorderLayout.WEST);
			
			this.add(health1,BorderLayout.NORTH);
			this.add(img1, BorderLayout.CENTER);
			this.add(stats1,BorderLayout.SOUTH);
			
			this.setVisible(true);
			
		}
		public void setWarrior(Warrior w) {
			this.w = w;
		}
		public Warrior getWarrior() {
			return w;
		}
	
	}
	class WindowCharacters extends JFrame implements ActionListener{
		private JFrame myFrame;
		private WarriorContainer warriors;
		WindowCharacters(){
			myFrame = new JFrame();
			myFrame.setLayout(new GridLayout(3,3));
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			warriors = new WarriorContainer();
			Image img;
			Image dimg;
			ImageIcon icon;
			for (Warrior w : warriors.getWarriors()) {
				img = mipantalla.getImage(w.getUrl());
				dimg = img.getScaledInstance(100, 200, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				WarriorButton wb = new WarriorButton(icon,w.getId());
				if (w instanceof Human) {
					wb.setBackground(Color.CYAN);
				}
				if (w instanceof Elf) {
					wb.setBackground(Color.RED);
				}
				if (w instanceof Dwarf) {
					wb.setBackground(Color.YELLOW);
				}
				wb.addActionListener(this);
				myFrame.add(wb);
			}
			
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setBounds(200,300,800,800);
			myFrame.setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			int idWarrior = ((WarriorButton) (e.getSource())).getID();
			Warrior warriorSelected = warriors.getWarrior(idWarrior);
			ch1 = new Ch1();
			ch1.setWarrior(warriorSelected);
			myFrame.dispose();
			new Window();
		}
	}
	/*
class ChooseWarrior implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		new WindowCharacters();
	}
	}*/
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==ch_character) {
			new WindowCharacters();
		}
	}
}


class WarriorButton extends JButton{
	private int id;

	public WarriorButton() {
		super();
	}

	public WarriorButton(ImageIcon i, int id) {
		super();
		this.setIcon(i);
		this.id = id;
	}
	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}
	
}


class RankingWindow extends JPanel{
	
}
