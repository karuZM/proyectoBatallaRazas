import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

public class Fight {

	public static void main(String[] args) {
		new Window0();
		//new Window();
		//new WindowCharacters();
		//new GlobalRanking();
		//new DefeatedEnemies();
		//new InjuriesSuffered();
	}
}
class Window0 extends JFrame{
	public String name;
	private JPanel up,down,left,right,center,mid,buttons,titleuser,usernamep;
	private JButton b1,b2;
	private JTextField username;
	private JLabel title,user;
	public Window0(){
		setBackground(Color.BLACK);
		up = new JPanel();
		left = new JPanel();
		right = new JPanel();
		down = new JPanel();
		center = new JPanel();
		up.setBackground(Color.black);
		right.setBackground(Color.black);
		left.setBackground(Color.black);
		down.setBackground(Color.black);
		center.setBackground(Color.black);
		up.setPreferredSize(new Dimension(100,300));
		left.setPreferredSize(new Dimension(50,50));
		right.setPreferredSize(new Dimension(50,50));
		down.setPreferredSize(new Dimension(50,50));
		center.setPreferredSize(new Dimension(50,50));
		add(up,BorderLayout.NORTH);
		add(left,BorderLayout.WEST);
		add(right,BorderLayout.EAST);
		add(down,BorderLayout.SOUTH);
		add(center,BorderLayout.CENTER);
		titleuser = new JPanel();
		titleuser.setBackground(Color.black);
		titleuser.setLayout(new BorderLayout());
		title = new JLabel("Battle of Races", SwingConstants.CENTER);
		title.setFont(new Font("arial", Font.BOLD,70));
		title.setForeground(Color.white);
		user = new JLabel("Enter your username:");
		user.setForeground(Color.white);
		buttons = new JPanel();
		buttons.setBackground(Color.BLACK);
		b1 = new JButton("Jugar");
		b2 = new JButton("Salir");
		b1.setBackground(Color.white);
		b2.setBackground(Color.white);
		usernamep = new JPanel();
		usernamep.setLayout(new BorderLayout());
		usernamep.setBackground(Color.BLACK);
		username = new JTextField(40);
		username.setForeground(Color.GRAY);
		mid = new JPanel();
		mid.setPreferredSize(new Dimension(60,60));
		mid.setBackground(Color.black);
		
		up.add(titleuser,BorderLayout.NORTH);
		center.add(buttons,BorderLayout.SOUTH);
		titleuser.add(mid,BorderLayout.CENTER);
		titleuser.add(title,BorderLayout.NORTH);
		titleuser.add(usernamep,BorderLayout.SOUTH);
		
		usernamep.add(user,BorderLayout.WEST);
		usernamep.add(username,BorderLayout.EAST);
		buttons.add(b1);
		buttons.add(b2);
		
		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String name = username.getText();
				if (name.equalsIgnoreCase("")) {
						JOptionPane.showMessageDialog(null, "Enter a username");
				}else {
					DatabaseInsert ins = new DatabaseInsert();
					ins.insertplayer(name);
					new Window();
					dispose();
				}
				
			}
			
		});
		b2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
			
		});
		
		this.setSize(900,500);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
}
class Window extends JFrame implements ActionListener,WindowListener{
	private WarriorContainer warriors = new WarriorContainer();
	private Warrior w2 = warriors.randomWarrior();
	private ImageComponent vs = new ImageComponent("ImagenesProjecto/Extra/vs.png");
	private Ch1 ch1 = new Ch1();
	private Ch1 ch2 = new Ch1();
	private JPanel choose,fight_buttons,fight;
	private JButton ch_character, ch_weapon, ranking, fightButton, clearConsole;
	private JTextArea console;
	private WeaponContainer wepCont_w2 = new WeaponContainer();
	private int round = 0;
	private boolean battle = false;
	private boolean start_round = true;
	private Ch1[] fightingWarriors = new Ch1[2];
	private int initialHealth,oppInitialHealth;
	private boolean win;
	private int total_points;
	private boolean rankingInserted = false;
	Window(){
		ch2.setWeapon(wepCont_w2.getRandomWeapon(ch2.getWarrior()));
		choose = new JPanel();
		choose.setBackground(Color.BLACK);
		ch_character = new JButton("Choose Character");
		ch_character.setBackground(Color.WHITE);
		ch_character.addActionListener(this);
		ch_weapon = new JButton("Choose Weapon");
		ch_weapon.setBackground(Color.WHITE);
		ch_weapon.addActionListener(this);
		ranking = new JButton("Ranking");
		ranking.setBackground(Color.WHITE);
		ranking.addActionListener(this);
		choose.add(ch_character);
		choose.add(ch_weapon);
		choose.add(ranking);

		fight = new JPanel();
		fight_buttons = new JPanel();
		fight_buttons.setBackground(Color.BLACK);
		fight.setLayout(new BorderLayout());
		fightButton = new JButton("Fight");
		fightButton.setBackground(Color.WHITE);
		fightButton.addActionListener(this);
		clearConsole = new JButton("Clear Console");
		clearConsole.setBackground(Color.WHITE);
		clearConsole.addActionListener(this);
		fight_buttons.add(fightButton);
		fight_buttons.add(clearConsole);
		console = new JTextArea(10,800);
		console.setBackground(Color.BLACK);
		console.setForeground(Color.WHITE);
		JScrollPane sp = new JScrollPane(console);
		console.setEditable(false);
		
		fight.add(fight_buttons, BorderLayout.NORTH);
		fight.add(sp,BorderLayout.SOUTH);
		
		this.add(choose,BorderLayout.NORTH);
		this.add(vs,BorderLayout.CENTER);
		this.add(ch1,BorderLayout.WEST);
		this.add(ch2,BorderLayout.EAST);
		this.add(fight,BorderLayout.SOUTH);
		
		this.setBackground(Color.LIGHT_GRAY);
		this.addWindowListener(this);
		this.setSize(800,800);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);

	}
//	public void paint(Graphics g ) {
//        super.paint(g);
//            Graphics2D g2d=(Graphics2D)g;
//            Toolkit t = Toolkit.getDefaultToolkit();
//            Image imagen = t.getImage("ImagenesProjecto/Extra/vs.png");
//            imagen.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
//            g2d.drawImage(imagen.getScaledInstance(100, 125, Image.SCALE_SMOOTH),345,200,this);
//    }

	public void setCh1(Ch1 ch1) {
		this.ch1 = ch1;
	}
	class ImageComponent extends JPanel{
	    private BufferedImage image;
	    
	    ImageComponent(String urlFoto){
	        try {
	            image = ImageIO.read(new File(urlFoto));
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public void paint(Graphics g) {

	        
	          Graphics2D g2d = (Graphics2D)g;
	          int x = 0; 
	          int y = 0;
	          g2d.drawImage(image.getScaledInstance(100, 125, Image.SCALE_SMOOTH), 10, 125, this);
	         
	    }
	    public void setImage(String urlFoto) {
	        System.out.println("establecemos en el panel la foto "+urlFoto);
	        try {
	            this.image = ImageIO.read(new File(urlFoto));
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        repaint();
	    }
	}
	class Ch1 extends JPanel{
		private Warrior w = warriors.randomWarrior();
		private JPanel habilities1 ,stats1;
		private JLabel name1,weapon1,power1_,agility1_,speed1_,defense1_;
		private JProgressBar health1,power1,agility1,speed1,defense1;
		private JLabel etiquetaWarrior;
		private Image img,dimg;
		private ImageIcon icon;
		private Toolkit mipantalla = Toolkit.getDefaultToolkit();
		Ch1(){
			wepCont_w2 = new WeaponContainer();
			//w.setWeapon(wepCont_w2.getRandomWeapon(w));
			this.setLayout(new BorderLayout());
			health1 = new JProgressBar(0,w.getHealth());
			health1.setValue(w.getHealth());
			health1.setStringPainted(true);
			health1.setForeground(Color.GREEN);
			
			etiquetaWarrior = new JLabel();
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			img = mipantalla.getImage(w.getUrl());
//			dimg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH);
//			icon = new ImageIcon(dimg);
//			img1.setIcon(icon);
			etiquetaWarrior.setIcon(new ImageIcon(img.getScaledInstance(300, 300, Image.SCALE_SMOOTH)));


			
			stats1 = new JPanel();
			stats1.setLayout(new BorderLayout());
			name1 = new JLabel(w.getName(), SwingConstants.CENTER);
			weapon1 = new JLabel();
			if(w.getWeapon()!=null) {
			img = mipantalla.getImage(w.getWeapon().getUrl());
			dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			weapon1.setIcon(icon);
			}
			else {
				img = mipantalla.getImage("ImagenesProjecto/Extra/cross.png");
				dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				weapon1.setIcon(icon);
			}
			
			habilities1 = new JPanel();
			habilities1.setLayout(new GridLayout(4,2));
			power1_ = new JLabel("Power");
			power1 = new JProgressBar(0,11);
			power1.setValue(w.getStrength());
			power1.setForeground(Color.BLUE);
			
			agility1_ = new JLabel("Agility");
			agility1 = new JProgressBar(0,7);
			agility1.setValue(w.getAgility());
			agility1.setForeground(Color.RED);
			
			speed1_ = new JLabel("Speed");
			speed1 = new JProgressBar(0,12);
			speed1.setValue(w.getSpeed());
			speed1.setForeground(Color.YELLOW);
			
			defense1_ = new JLabel("Defense");
			defense1 = new JProgressBar(0,4);
			defense1.setValue(w.getDefense());
			defense1.setForeground(Color.PINK);
			
			habilities1.add(power1_);
			habilities1.add(power1);
			habilities1.add(agility1_);
			habilities1.add(agility1);
			habilities1.add(speed1_);
			habilities1.add(speed1);
			habilities1.add(defense1_);
			habilities1.add(defense1);
			
			stats1.add(name1,BorderLayout.NORTH);
			stats1.add(habilities1,BorderLayout.EAST);
			stats1.add(weapon1, BorderLayout.WEST);
			
			this.setBackground(Color.LIGHT_GRAY);
			this.add(health1,BorderLayout.NORTH);
			this.add(etiquetaWarrior, BorderLayout.CENTER);
			this.add(stats1,BorderLayout.SOUTH);
			
			this.setVisible(true);
			
		}
		public void setWarrior(Warrior warrior) {
			this.w = warrior;
			Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			img = mipantalla.getImage(this.w.getUrl());
			etiquetaWarrior.setIcon(new ImageIcon(img.getScaledInstance(300, 300, Image.SCALE_SMOOTH)));
			name1.setText(this.w.getName());
			if(this.w.getWeapon()!=null) {
			setWeaponImage();
			}else {
				img = mipantalla.getImage("ImagenesProjecto/Extra/cross.png");
				dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				weapon1.setIcon(icon);
			}
			health1.setMaximum(w.getHealth());
			health1.setValue(w.getHealth());
			setStats();
			setHealth();
		}
		public Warrior getWarrior() {
			return w;
			
		}
		public void setStats() {
			if (this.w.getWeapon()!=null) {
				speed1.setValue(this.w.getSpeed()+this.w.getWeapon().getSpeed());
				power1.setValue(this.w.getStrength()+this.w.getWeapon().getStrength());
			}else {
				power1.setValue(this.w.getStrength());
				speed1.setValue(this.w.getSpeed());
			}
			
			agility1.setValue(this.w.getAgility());
			defense1.setValue(this.w.getDefense());
			
			
		}
		public void setWeaponImage() {
			if(this.w.getWeapon()!=null) {
				Image img = mipantalla.getImage(this.w.getWeapon().getUrl());
				weapon1.setIcon(new ImageIcon(img.getScaledInstance(50, 50, Image.SCALE_SMOOTH)));
			}
			else {
				img = mipantalla.getImage("ImagenesProjecto/Extra/cross.png");
				dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				weapon1.setIcon(icon);			}
		}
		
		public void setWeapon(Weapon weap) {
			this.w.setWeapon(weap);
			setWeaponImage();
			setStats();
		}
		public void setHealth() {
			health1.setValue(this.w.getHealth());
			if (health1.getValue()>health1.getMaximum()/2) {
				health1.setForeground(Color.green);
			}
			else {
				if(health1.getValue()>health1.getMaximum()/5) {
					health1.setForeground(Color.orange);
				}
				else{
					health1.setForeground(Color.red);
				}
			}
			
		}
		public void resetStats() {
			if(this.w instanceof Human) {
				this.w.setHealth(50);
			}
			if(this.w instanceof Elf) {
				this.w.setHealth(40);
			}
			if(this.w instanceof Dwarf) {
				this.w.setHealth(60);
			}
			this.w.setWeapon(null);
			setStats();
			setWeaponImage();
			setHealth();
		}
		// metodo setear estados
		// speed1.setValue(w.getSpeed());
	
	}
	class WindowCharacters extends JFrame implements ActionListener{
		private JFrame myFrame;
		private WarriorContainer warriors;
		WindowCharacters(){
			myFrame = new JFrame();
			myFrame.setLayout(new GridLayout(3,3));
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			warriors = new WarriorContainer();
			Image img;
			Image dimg;
			ImageIcon icon;
			for (Warrior w : warriors.getWarriors()) {
				img = mipantalla.getImage(w.getUrl());
				dimg = img.getScaledInstance(100, 200, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				WarriorButton wb = new WarriorButton(icon,w.getId());
				if (w instanceof Human) {
					wb.setBackground(new Color(177,193,230));
				}
				if (w instanceof Elf) {
					wb.setBackground(new Color(185,215,150));
				}
				if (w instanceof Dwarf) {
					wb.setBackground(new Color(223,165,165));
				}
				wb.addActionListener(this);
				myFrame.add(wb);
			}
			
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setSize(800,800);
			myFrame.setLocationRelativeTo(null);
			myFrame.setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			int idWarrior = ((WarriorButton) (e.getSource())).getID();
			Warrior warriorSelected = warriors.getWarrior(idWarrior);
			ch1.setWarrior(warriorSelected);
			myFrame.dispose();
		}
	}
	class WindowWeapons extends JFrame implements ActionListener{
		private JFrame myFrame;
		private WeaponContainer weapCont = new WeaponContainer();
		WindowWeapons(Warrior w){
			myFrame = new JFrame();
			myFrame.setLayout(new GridLayout(3,3));
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			Image dimg;
			ImageIcon icon;
			for (Weapon weapon : weapCont.getWeapons()) {
				if(weapon.getClases().contains(w.getClass().getSimpleName())) {
					icon = new ImageIcon(mipantalla.getImage(weapon.getUrl()).getScaledInstance(100, 200, Image.SCALE_SMOOTH));
					WeaponButton wb = new WeaponButton(icon,weapon.getId());
					wb.addActionListener(this);
					wb.setBackground(Color.white);
					myFrame.add(wb);
				}
			}
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setSize(800,800);
			myFrame.setLocationRelativeTo(null);
			myFrame.setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			int idWeapon = ((WeaponButton)(e.getSource())).getId();
			Weapon weaponSelected = weapCont.getWeapon(idWeapon);
			//ch1.setWarrior(ch1.getWarrior(),weaponSelected);
			ch1.setWeapon(weaponSelected);
			myFrame.dispose();
		}
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==ranking) {
			new WindowRanking();
		}
		if (e.getSource()==ch_character) {
			if (rankingInserted) {
				JOptionPane.showMessageDialog(null, "You can't change your warrior!");
			}
			else {
				new WindowCharacters();
			}
		}
		if (e.getSource()==ch_weapon) {
			if(battle) {
				JOptionPane.showMessageDialog(null, "You can't change your weapon in a middle of a battle!");
			}
			else {
				new WindowWeapons(ch1.getWarrior());
			}
		}
		if (e.getSource()==fightButton) {
			if (ch1.getWarrior().getWeapon()==null) {
				JOptionPane.showMessageDialog(null, "You have to choose a weapon!");
			}else {
				if (battle==false) {
					DatabaseInsert insBattle = new DatabaseInsert();
					if (rankingInserted==false) {
						insBattle.insertRanking(ch1.getWarrior().getId());
						rankingInserted = true;
					}
					insBattle.insertBattle(ch1.getWarrior().getId(), ch1.getWarrior().getWeapon().getId(),
							ch2.getWarrior().getId(), ch2.getWarrior().getWeapon().getId());
					if (ch1.getWarrior().getSpeed()+ch1.getWarrior().getWeapon().getSpeed()>ch2.getWarrior().getSpeed()+ch2.getWarrior().getWeapon().getSpeed()) {
						fightingWarriors[0] = ch1;
						fightingWarriors[1] = ch2;
					}
					else if(ch1.getWarrior().getSpeed()+ch1.getWarrior().getWeapon().getSpeed()<ch2.getWarrior().getSpeed()+ch2.getWarrior().getWeapon().getSpeed()) {
						fightingWarriors[0] = ch2;
						fightingWarriors[1] = ch1;
					}
					else if (ch1.getWarrior().getAgility()>ch2.getWarrior().getAgility()) {
						fightingWarriors[0] = ch1;
						fightingWarriors[1] = ch2;
					}
					else if (ch1.getWarrior().getAgility()<ch2.getWarrior().getAgility()) {
						fightingWarriors[0] = ch2;
						fightingWarriors[1] = ch1;
					}
					else {
						int n = (int)(Math.random()*2);
						fightingWarriors[n] = ch1;
						if(n==0) {
							fightingWarriors[1] = ch2;
						}
						else {
							fightingWarriors[0] = ch2;
						}
					}
					battle = true;
				}
				if(start_round) {
					initialHealth = ch1.getWarrior().getHealth();
					oppInitialHealth = ch2.getWarrior().getHealth();
					start_round = false;
				}
				String result = fightingWarriors[round%2].getWarrior().attack(fightingWarriors[(round+1)%2].getWarrior());
				
				if (round%2==1) {
					if (ch1.getWarrior().getHealth()<0) {
						ch1.getWarrior().setHealth(0);
					}
					if (ch2.getWarrior().getHealth()<0) {
						ch2.getWarrior().setHealth(0);
					}
					int healthLost  = initialHealth-ch1.getWarrior().getHealth();
					int oppHealthLost = oppInitialHealth-ch2.getWarrior().getHealth();
					DatabaseInsert insertRound = new DatabaseInsert();
					insertRound.insertRound(oppHealthLost, healthLost, ch1.getWarrior().getId());
					start_round = true;
					
				}
				//fightingWarriors[(round+1)%2].setStats();
				console.setText(console.getText()+"\n"+result);
				fightingWarriors[(round+1)%2].setHealth();

				if(ch1.getWarrior().getHealth()<=0 | ch2.getWarrior().getHealth()<=0) {
					battle = false;
					round = 0;
					start_round = true;
					if(ch1.getWarrior().getHealth()<=0) {
						win = false;
						JOptionPane.showMessageDialog(null, "You lost the battle!");
						new WindowKF();
						dispose();
					}else {
						win = true;
						int points = ch1.getWarrior().getHealth();
						DatabaseInsert updatePoints = new DatabaseInsert();
						updatePoints.updatePoints(points);
						total_points = total_points+points;
						JOptionPane.showMessageDialog(null, "You won the battle!");
						new WindowKF();
										
						}
				}
				else {
					if(fightingWarriors[round%2].getWarrior().getSpeed()+fightingWarriors[round%2].getWarrior().getWeapon().getSpeed()<=
							fightingWarriors[(round+1)%2].getWarrior().getSpeed()+fightingWarriors[(round+1)%2].getWarrior().getWeapon().getSpeed()) {
						round++;
					}else {
						int number = (int)(Math.random()*100);
						if(fightingWarriors[round%2].getWarrior().getSpeed()+fightingWarriors[round%2].getWarrior().getWeapon().getSpeed()-
								fightingWarriors[(round+1)%2].getWarrior().getSpeed()+fightingWarriors[(round+1)%2].getWarrior().getWeapon().getSpeed()>number) {
							console.setText(console.getText()+"\n"+fightingWarriors[round%2].getWarrior().getName()+" will attack again because of his great speed!");
						}else {
							round++;
						}
				}
				}

				
			}
		}
		if(e.getSource()==clearConsole) {
			console.setText("");
		}
	}
	class WindowKF extends JFrame implements ActionListener, WindowListener{
	    
	    //Creacion de un panel
	    private JPanel KF,buttons;
	    
	    
	    //Creacion de los botones
	    
	    private JButton yes,no;
	    
	    private JLabel title;
	    private boolean closeWindow = false;;
	    
	     WindowKF() {
	        //JPanel
	        KF = new JPanel();
	        KF.setBackground(Color.BLACK);
	        buttons = new JPanel();
	        buttons.setBackground(Color.BLACK);
	        KF.setLayout(new BorderLayout());
	        this.add(KF);
	        KF.add(buttons,BorderLayout.SOUTH);
	        
	        //JLabel
	        if(win) {
		        title= new JLabel("Do you want to keep fighting?",SwingConstants.CENTER);
	        }
	        else {
		        title= new JLabel("Do you want to play again? (New user)",SwingConstants.CENTER);
	        }
	        title.setFont(new Font("arial", Font.BOLD,20));
	        title.setForeground(Color.WHITE);
	        KF.add(title,BorderLayout.CENTER);
	        
	    
	        //Buttons
	        yes = new JButton("yes");
	        yes.setBackground(Color.WHITE);
	        no = new JButton("no");
	        no.setBackground(Color.WHITE);
	        buttons.add(yes);
	        buttons.add(no);
	    
	     yes.addActionListener(this);
	     no.addActionListener(this);
	     this.addWindowListener(this);
	     this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	     this.setSize(500,200);
		 this.setLocationRelativeTo(null);
	     setVisible(true);
	     }
	public void actionPerformed(ActionEvent e) {
		console.setText("");
		if (e.getSource()==yes) {
			closeWindow = true;
			if (win==true) {
				ch2.resetStats();
				Warrior newWarrior = warriors.randomWarrior();
				newWarrior.setWeapon(wepCont_w2.getRandomWeapon(newWarrior));
				ch2.setWarrior(newWarrior);
				ch1.resetStats();
				dispose();
			}
			else {
				DatabaseInsert updateRanking = new DatabaseInsert();
				updateRanking.updateTotalPoints(total_points);
				rankingInserted = false;
				new Window0();
				dispose();
			}
    }
		if(e.getSource()==no) {
			DatabaseInsert updateRanking = new DatabaseInsert();
    		updateRanking.updateTotalPoints(total_points);
            System.exit(0);
		}
    
}
	@Override
	public void windowOpened(WindowEvent e) {
	}
	@Override
	public void windowClosing(WindowEvent e) {
	}
	@Override
	public void windowClosed(WindowEvent e) {
		if (!closeWindow) {
			DatabaseInsert updateRanking = new DatabaseInsert();
			updateRanking.updateTotalPoints(total_points);
			System.exit(0);
		}
		
	}
	@Override
	public void windowIconified(WindowEvent e) {
	}
	@Override
	public void windowDeiconified(WindowEvent e) {
	}
	@Override
	public void windowActivated(WindowEvent e) {
	}
	@Override
	public void windowDeactivated(WindowEvent e) {
		
	}
	}
	
	//WindowListener methods from the main window
	@Override
	public void windowOpened(WindowEvent e) {
	}
	@Override
	public void windowClosing(WindowEvent e) {
	}
	@Override
	public void windowClosed(WindowEvent e) {
		DatabaseInsert updatePoints = new DatabaseInsert();
		updatePoints.updatePoints(total_points);
	}
	@Override
	public void windowIconified(WindowEvent e) {
	}
	@Override
	public void windowDeiconified(WindowEvent e) {
	}
	@Override
	public void windowActivated(WindowEvent e) {
	}
	@Override
	public void windowDeactivated(WindowEvent e) {
	}
}


class WarriorButton extends JButton{
	private int id;

	public WarriorButton() {
		super();
	}

	public WarriorButton(ImageIcon i, int id) {
		super();
		this.setIcon(i);
		this.id = id;
	}
	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}
	
}
class WeaponButton extends JButton{
	private int id;

	public WeaponButton() {
		super();
	}

	public WeaponButton(ImageIcon i,int id) {
		super();
		this.setIcon(i);
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}


class GlobalRanking extends JFrame{
	private Ranking ranking = new Ranking();
	private ArrayList<String[]> globalRanking = ranking.globalRanking();
	private JPanel table;
	private JLabel title1,name,points,warrior;
	GlobalRanking(){
		setBackground(Color.black);
		title1 = new JLabel("GLOBAL RANKING", SwingConstants.CENTER);
		title1.setForeground(Color.black);
		title1.setBackground(Color.black);
		table = new JPanel();
		
		
		table.setLayout(new GridLayout(globalRanking.size()+1,3));
		table.setBackground(Color.black);
		name = new JLabel("NAME");
		name.setForeground(Color.yellow);	
		points = new JLabel("POINTS");
		points.setForeground(Color.yellow);
		warrior = new JLabel("WARRIOR");
		warrior.setForeground(Color.yellow);
		table.add(name);
		table.add(points);
		table.add(warrior);
		for (String[] row : globalRanking) {
			JLabel name1 = new JLabel(row[0]);
			JLabel points1 = new JLabel(row[1]);
			JLabel warrior1 = new JLabel(row[2]);
			name1.setForeground(Color.white);
			points1.setForeground(Color.white);
			warrior1.setForeground(Color.white);
			table.add(name1);
			table.add(points1);
			table.add(warrior1);
		}

		this.add(title1, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600,300);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
}
class DefeatedEnemies extends JFrame{
	private Ranking ranking = new Ranking();
	private ArrayList<String[]> defeatedEnemies = ranking.defeatedEnemies();
	private JPanel up,down,right,left,table;
	private JLabel title,name,defEn;
		DefeatedEnemies(){
			title = new JLabel("DEFEATED ENEMIES RANKING",SwingConstants.CENTER);
			title.setForeground(Color.black);
			title.setBackground(Color.white);
			table = new JPanel();
			table.setLayout(new GridLayout(defeatedEnemies.size()+1,2));
			table.setBackground(Color.black);
			name = new JLabel("NAME");
			name.setForeground(Color.yellow);
			defEn = new JLabel("DEFEATED ENEMIES");
			defEn.setForeground(Color.yellow);
			table.add(name);
			table.add(defEn);
			for (String[] row : defeatedEnemies) {
				JLabel name1 = new JLabel(row[0]);
				name1.setForeground(Color.white);
				JLabel defEn1 = new JLabel(row[1]);
				defEn1.setForeground(Color.white);
				table.add(name1);
				table.add(defEn1);
			}
			this.add(title, BorderLayout.NORTH);
			this.add(table, BorderLayout.CENTER);
			
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setSize(450,300);
			this.setLocationRelativeTo(null);
			this.setVisible(true);
	}

}
class InjuriesCaused extends JFrame{
	private Ranking ranking = new Ranking();
	private ArrayList<String[]> injuriesCaused = ranking.injuriesCaused();
	private JPanel up,down,right,left,table;
	private JLabel title,name,damCau,warr,weap;
	InjuriesCaused(){
		title = new JLabel("DAMAGE CAUSED RANKING",SwingConstants.CENTER);
		title.setForeground(Color.black);
		title.setBackground(Color.white);
		table = new JPanel();
		table.setLayout(new GridLayout(injuriesCaused.size()+1,4));
		table.setBackground(Color.black);
		name = new JLabel("NAME");
		name.setForeground(Color.yellow);
		damCau = new JLabel("INJURIES CAUSED");
		damCau.setForeground(Color.yellow);
		warr = new JLabel("WARRIOR");
		warr.setForeground(Color.yellow);
		weap = new JLabel("WEAPON");
		weap.setForeground(Color.yellow);
		table.add(name);
		table.add(damCau);
		table.add(warr);
		table.add(weap);
		for (String[] row : injuriesCaused) {
			JLabel name1 = new JLabel(row[0]);
			name1.setForeground(Color.white);
			JLabel damCau1 = new JLabel(row[1]);
			damCau1.setForeground(Color.white);
			JLabel warr1 = new JLabel(row[2]);
			warr1.setForeground(Color.white);
			JLabel weap1 = new JLabel(row[3]);
			weap1.setForeground(Color.white);
			table.add(name1);
			table.add(damCau1);
			table.add(warr1);
			table.add(weap1);
		}
		this.add(title, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600,300);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

}
class InjuriesSuffered extends JFrame{
	private Ranking ranking = new Ranking();
	private ArrayList<String[]> injuriesSuffered = ranking.injuriesSuffered();
	private JPanel up,down,right,left,table;
	private JLabel title,name,damSuf,warr,weap;
	InjuriesSuffered(){
		title = new JLabel("DAMAGE SUFFERED RANKING",SwingConstants.CENTER);
		title.setForeground(Color.black);
		title.setBackground(Color.white);
		table = new JPanel();
		table.setLayout(new GridLayout(injuriesSuffered.size()+1,4));
		table.setBackground(Color.black);
		name = new JLabel("NAME");
		name.setForeground(Color.yellow);
		damSuf = new JLabel("INJURIES SUFFERED");
		damSuf.setForeground(Color.yellow);
		warr = new JLabel("WARRIOR");
		warr.setForeground(Color.yellow);
		weap = new JLabel("WEAPON");
		weap.setForeground(Color.yellow);
		table.add(name);
		table.add(damSuf);
		table.add(warr);
		table.add(weap);
		for (String[] row : injuriesSuffered) {
			JLabel name1 = new JLabel(row[0]);
			name1.setForeground(Color.white);
			JLabel damSuf1 = new JLabel(row[1]);
			damSuf1.setForeground(Color.white);
			JLabel warr1 = new JLabel(row[2]);
			warr1.setForeground(Color.white);
			JLabel weap1 = new JLabel(row[3]);
			weap1.setForeground(Color.white);
			table.add(name1);
			table.add(damSuf1);
			table.add(warr1);
			table.add(weap1);
		}
		this.add(title, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600,300);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

}
class WindowRanking extends JFrame implements ActionListener {
		private JFrame myFrame;
		private JPanel myPanel;
		private JButton global,enemies,caused,suffered;
		WindowRanking(){
			myFrame = new JFrame();
			myPanel = new JPanel();
			myPanel.setLayout(new FlowLayout());
			myPanel.setBackground(Color.black);
			global = new JButton("Global Ranking");
			enemies = new JButton("Enemies Defeated");
			caused = new JButton("Injuries Caused");
			suffered = new JButton("Injuries Suffered");
			global.addActionListener(this);
			global.setBackground(Color.white);
			enemies.addActionListener(this);
			enemies.setBackground(Color.white);
			caused.addActionListener(this);
			caused.setBackground(Color.white);
			suffered.addActionListener(this);
			suffered.setBackground(Color.white);
			myPanel.add(global);
			myPanel.add(enemies);
			myPanel.add(caused);
			myPanel.add(suffered);
			myFrame.add(myPanel);
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setSize(700,100);
			myFrame.setLocationRelativeTo(null);
			myFrame.setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == global) {
				new GlobalRanking();
			}else if(e.getSource() == enemies){
				new DefeatedEnemies();
			}else if(e.getSource()==caused) {
				new InjuriesCaused();
			}else if(e.getSource()==suffered) {
				new InjuriesSuffered();
			}
		}
	
}