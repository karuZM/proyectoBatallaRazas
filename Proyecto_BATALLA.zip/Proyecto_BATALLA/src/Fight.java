import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class Fight {

	public static void main(String[] args) {
		new Window0();
		//new Window();
		//new WindowCharacters();
		//new GlobalRanking();
		//new DefeatedEnemies();
	}
}
class Window0 extends JFrame{
	public String name;
	private JPanel up,down,left,right,center,mid,buttons,titleuser,usernamep;
	private JButton b1,b2;
	private JTextField username;
	private JLabel title,user;
	private int round = 0;
	public Window0(){
		setBackground(Color.BLACK);
		up = new JPanel();
		left = new JPanel();
		right = new JPanel();
		down = new JPanel();
		center = new JPanel();
		up.setBackground(Color.black);
		right.setBackground(Color.black);
		left.setBackground(Color.black);
		down.setBackground(Color.black);
		center.setBackground(Color.black);
		up.setPreferredSize(new Dimension(100,300));
		left.setPreferredSize(new Dimension(50,50));
		right.setPreferredSize(new Dimension(50,50));
		down.setPreferredSize(new Dimension(50,50));
		center.setPreferredSize(new Dimension(50,50));
		add(up,BorderLayout.NORTH);
		add(left,BorderLayout.WEST);
		add(right,BorderLayout.EAST);
		add(down,BorderLayout.SOUTH);
		add(center,BorderLayout.CENTER);
		titleuser = new JPanel();
		titleuser.setBackground(Color.black);
		titleuser.setLayout(new BorderLayout());
		title = new JLabel("Battle of Races", SwingConstants.CENTER);
		title.setFont(new Font("arial", Font.BOLD,70));
		title.setForeground(Color.white);
		user = new JLabel("Enter your username:");
		user.setForeground(Color.white);
		buttons = new JPanel();
		buttons.setBackground(Color.BLACK);
		b1 = new JButton("Jugar");
		b2 = new JButton("Salir");
		b1.setBackground(Color.white);
		b2.setBackground(Color.white);
		usernamep = new JPanel();
		usernamep.setLayout(new BorderLayout());
		usernamep.setBackground(Color.BLACK);
		username = new JTextField(40);
		username.setForeground(Color.GRAY);
		mid = new JPanel();
		mid.setPreferredSize(new Dimension(60,60));
		mid.setBackground(Color.black);
		
		up.add(titleuser,BorderLayout.NORTH);
		center.add(buttons,BorderLayout.SOUTH);
		titleuser.add(mid,BorderLayout.CENTER);
		titleuser.add(title,BorderLayout.NORTH);
		titleuser.add(usernamep,BorderLayout.SOUTH);
		
		usernamep.add(user,BorderLayout.WEST);
		usernamep.add(username,BorderLayout.EAST);
		buttons.add(b1);
		buttons.add(b2);
		
		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String name = username.getText();
				if (name.equalsIgnoreCase("")) {
						JOptionPane.showMessageDialog(null, "Enter a username");
				}else {
					new Window();
					dispose();
				}
				
			}
			
		});
		b2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
			
		});
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(200,100,900,500);
		this.setVisible(true);
	}
	
}
class Window extends JFrame implements ActionListener{
	private WarriorContainer warriors = new WarriorContainer();
	private Warrior w2 = warriors.randomWarrior();
	private Ch1 ch1 = new Ch1();
	private Ch1 ch2 = new Ch1();
	private JPanel choose,fight_buttons,fight;
	private JButton ch_character, ch_weapon, ranking, fightButton, clearConsole;
	private JTextArea console;
	private WeaponContainer wepCont_w2 = new WeaponContainer();
	Window(){
		ch2.setWeapon(wepCont_w2.getRandomWeapon(ch2.getWarrior()));
		choose = new JPanel();
		ch_character = new JButton("Choose Character");
		ch_character.addActionListener(this);
		ch_weapon = new JButton("Choose Weapon");
		ch_weapon.addActionListener(this);
		ranking = new JButton("Ranking");
		choose.add(ch_character);
		choose.add(ch_weapon);
		choose.add(ranking);

		fight = new JPanel();
		fight_buttons = new JPanel();
		fight.setLayout(new BorderLayout());
		fightButton = new JButton("Fight");
		fightButton.addActionListener(this);
		clearConsole = new JButton("Clear Console");
		clearConsole.addActionListener(this);
		fight_buttons.add(fightButton);
		fight_buttons.add(clearConsole);
		console = new JTextArea(10,800);
		console.setEditable(false);
		
		fight.add(fight_buttons, BorderLayout.NORTH);
		fight.add(console,BorderLayout.SOUTH);
		
		this.add(choose,BorderLayout.NORTH);
		this.add(ch1,BorderLayout.WEST);
		this.add(ch2,BorderLayout.EAST);
		this.add(fight,BorderLayout.SOUTH);
		
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(200,300,800,800);
		this.setVisible(true);

	}
	public void setCh1(Ch1 ch1) {
		this.ch1 = ch1;
	}
	class Ch1 extends JPanel{
		private Warrior w = warriors.randomWarrior();
		private JPanel habilities1 ,stats1;
		private JLabel name1,weapon1,power1_,agility1_,speed1_,defense1_;
		private JProgressBar health1,power1,agility1,speed1,defense1;
		JLabel etiquetaWarrior;
		Ch1(){
			wepCont_w2 = new WeaponContainer();
			//w.setWeapon(wepCont_w2.getRandomWeapon(w));
			this.setLayout(new BorderLayout());
			health1 = new JProgressBar(0,w.getHealth());
			health1.setValue(w.getHealth());
			health1.setStringPainted(true);
			health1.setForeground(Color.GREEN);
			
			etiquetaWarrior = new JLabel();
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			Image dimg;
			ImageIcon icon;
			img = mipantalla.getImage(w.getUrl());
//			dimg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH);
//			icon = new ImageIcon(dimg);
//			img1.setIcon(icon);
			etiquetaWarrior.setIcon(new ImageIcon(img.getScaledInstance(300, 300, Image.SCALE_SMOOTH)));


			
			stats1 = new JPanel();
			stats1.setLayout(new BorderLayout());
			name1 = new JLabel(w.getName(), SwingConstants.CENTER);
			weapon1 = new JLabel();
			if(w.getWeapon()!=null) {
			img = mipantalla.getImage(w.getWeapon().getUrl());
			dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			weapon1.setIcon(icon);
			}
			
			habilities1 = new JPanel();
			habilities1.setLayout(new GridLayout(4,2));
			power1_ = new JLabel("Power");
			power1 = new JProgressBar(0,11);
			power1.setValue(w.getStrength());
			power1.setForeground(Color.BLUE);
			
			agility1_ = new JLabel("Agility");
			agility1 = new JProgressBar(0,7);
			agility1.setValue(w.getAgility());
			agility1.setForeground(Color.RED);
			
			speed1_ = new JLabel("Speed");
			speed1 = new JProgressBar(0,12);
			speed1.setValue(w.getSpeed());
			speed1.setForeground(Color.YELLOW);
			
			defense1_ = new JLabel("Defense");
			defense1 = new JProgressBar(0,4);
			defense1.setValue(w.getDefense());
			defense1.setForeground(Color.PINK);
			
			habilities1.add(power1_);
			habilities1.add(power1);
			habilities1.add(agility1_);
			habilities1.add(agility1);
			habilities1.add(speed1_);
			habilities1.add(speed1);
			habilities1.add(defense1_);
			habilities1.add(defense1);
			
			stats1.add(name1,BorderLayout.NORTH);
			stats1.add(habilities1,BorderLayout.EAST);
			stats1.add(weapon1, BorderLayout.WEST);
			
			this.add(health1,BorderLayout.NORTH);
			this.add(etiquetaWarrior, BorderLayout.CENTER);
			this.add(stats1,BorderLayout.SOUTH);
			
			this.setVisible(true);
			
		}
		public void setWarrior(Warrior w) {
			this.w = w;
			Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			img = mipantalla.getImage(w.getUrl());
			etiquetaWarrior.setIcon(new ImageIcon(img.getScaledInstance(300, 300, Image.SCALE_SMOOTH)));
			//w.setWeapon(wepCont_w2.getRandomWeapon(w));
			name1.setText(w.getName());
			if(w.getWeapon()!=null) {
			setWeaponImage();
			}else {
				weapon1.setIcon(null);
			}
			setStats();
		}
		public void setWarrior(Warrior w, Weapon weapon) {
			this.w = w;
			Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			img = mipantalla.getImage(w.getUrl());
			etiquetaWarrior.setIcon(new ImageIcon(img.getScaledInstance(300, 300, Image.SCALE_SMOOTH)));
			w.setWeapon(weapon);
			name1.setText(w.getName());
			setWeaponImage();
			setStats();
		}
		public Warrior getWarrior() {
			return w;
			
		}
		public void setStats() {
			if (w.getWeapon()!=null) {
				speed1.setValue(w.getSpeed()+w.getWeapon().getSpeed());
				power1.setValue(w.getStrength()+w.getWeapon().getStrength());
			}else {
				power1.setValue(w.getStrength());
				speed1.setValue(w.getSpeed());
			}
			
			agility1.setValue(w.getAgility());
			defense1.setValue(w.getDefense());
			
			
		}
		public void setWeaponImage() {
			Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img = mipantalla.getImage(w.getWeapon().getUrl());
			weapon1.setIcon(new ImageIcon(img.getScaledInstance(50, 50, Image.SCALE_SMOOTH)));
		}
		
		public void setWeapon(Weapon weap) {
			w.setWeapon(weap);
			setWarrior(w);
		}
		// metodo setear estados
		// speed1.setValue(w.getSpeed());
	
	}
	class WindowCharacters extends JFrame implements ActionListener{
		private JFrame myFrame;
		private WarriorContainer warriors;
		WindowCharacters(){
			myFrame = new JFrame();
			myFrame.setLayout(new GridLayout(3,3));
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			warriors = new WarriorContainer();
			Image img;
			Image dimg;
			ImageIcon icon;
			for (Warrior w : warriors.getWarriors()) {
				img = mipantalla.getImage(w.getUrl());
				dimg = img.getScaledInstance(100, 200, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				WarriorButton wb = new WarriorButton(icon,w.getId());
				if (w instanceof Human) {
					wb.setBackground(Color.CYAN);
				}
				if (w instanceof Elf) {
					wb.setBackground(Color.RED);
				}
				if (w instanceof Dwarf) {
					wb.setBackground(Color.YELLOW);
				}
				wb.addActionListener(this);
				myFrame.add(wb);
			}
			
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setBounds(200,300,800,800);
			myFrame.setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			int idWarrior = ((WarriorButton) (e.getSource())).getID();
			Warrior warriorSelected = warriors.getWarrior(idWarrior);
			ch1.setWarrior(warriorSelected);
			myFrame.dispose();
		}
	}
	class WindowWeapons extends JFrame implements ActionListener{
		private JFrame myFrame;
		private WeaponContainer weapCont = new WeaponContainer();
		WindowWeapons(Warrior w){
			myFrame = new JFrame();
			myFrame.setLayout(new GridLayout(3,3));
	        Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			Image dimg;
			ImageIcon icon;
			for (Weapon weapon : weapCont.getWeapons()) {
				if(weapon.getClases().contains(w.getClass().getSimpleName())) {
					icon = new ImageIcon(mipantalla.getImage(weapon.getUrl()).getScaledInstance(100, 200, Image.SCALE_SMOOTH));
					WeaponButton wb = new WeaponButton(icon,weapon.getId());
					wb.addActionListener(this);
					wb.setBackground(Color.white);
					myFrame.add(wb);
				}
			}
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setBounds(200,300,800,800);
			myFrame.setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			int idWeapon = ((WeaponButton)(e.getSource())).getId();
			Weapon weaponSelected = weapCont.getWeapon(idWeapon);
			ch1.setWarrior(ch1.getWarrior(),weaponSelected);
			myFrame.dispose();
		}
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==ch_character) {
			new WindowCharacters();
		}
		if (e.getSource()==ch_weapon) {
			new WindowWeapons(ch1.getWarrior());
		}
		if (e.getSource()==fightButton) {
			if (ch1.getWarrior().getWeapon()==null) {
				JOptionPane.showMessageDialog(null, "You have to choose a weapon!");
			}else {
				ArrayList<Warrior> fightingWarriors = new ArrayList<Warrior>();
				String result = ch1.getWarrior().attack(w2);
				console.setText(console.getText()+"\n"+result);
			}
		}
		if(e.getSource()==clearConsole) {
			console.setText("");
		}
	}
}


class WarriorButton extends JButton{
	private int id;

	public WarriorButton() {
		super();
	}

	public WarriorButton(ImageIcon i, int id) {
		super();
		this.setIcon(i);
		this.id = id;
	}
	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}
	
}
class WeaponButton extends JButton{
	private int id;

	public WeaponButton() {
		super();
	}

	public WeaponButton(ImageIcon i,int id) {
		super();
		this.setIcon(i);
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}


class GlobalRanking extends JFrame{
	private Ranking ranking = new Ranking();
	private ArrayList<String[]> globalRanking = ranking.globalRanking();
	private JPanel table;
	private JLabel title1,name,points,warrior;
	GlobalRanking(){
		title1 = new JLabel("GLOBAL RANKING", SwingConstants.CENTER);
		
		table = new JPanel();
		table.setLayout(new GridLayout(6,3));
		name = new JLabel("NAME");
		points = new JLabel("POINTS");
		warrior = new JLabel("WARRIOR");
		table.add(name);
		table.add(points);
		table.add(warrior);
		for (String[] row : globalRanking) {
			JLabel name1 = new JLabel(row[0]);
			JLabel points1 = new JLabel(row[1]);
			JLabel warrior1 = new JLabel(row[2]);
			table.add(name1);
			table.add(points1);
			table.add(warrior1);
		}
		this.add(title1, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);

		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(200,200,600,300);
		this.setVisible(true);
	}
}
class DefeatedEnemies extends JFrame{
	private Ranking ranking = new Ranking();
	private ArrayList<String[]> defeatedEnemies = ranking.defeatedEnemies();
	private JPanel table;
	private JLabel title,name,defEn;
	DefeatedEnemies(){
		title = new JLabel("DEFEATED ENEMIES RANKING",SwingConstants.CENTER);
		table = new JPanel();
		table.setLayout(new GridLayout(6,2));
		name = new JLabel("NAME");
		defEn = new JLabel("DEFEATED ENEMIES");
		table.add(name);
		table.add(defEn);
		for (String[] row : defeatedEnemies) {
			JLabel name1 = new JLabel(row[0]);
			JLabel defEn1 = new JLabel(row[1]);
			table.add(name1);
			table.add(defEn1);
		}
		this.add(title, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(200,200,400,300);
		this.setVisible(true);
	}

}
