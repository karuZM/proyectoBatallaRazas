import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Fight {

	public static void main(String[] args) {
		new Window();
		//new WindowCharacters();

	}
}
class Window extends JFrame{
	private Warrior ch1,ch2;
	private JPanel choose,character1,stats1,stats2,habilities1,habilities2,character2,fight;
	private JButton ch_character, ch_weapon, ranking, fightButton, clearConsole;
	private JProgressBar health1, health2,power1,power2,agility1,agility2,speed1,speed2,defense1,defense2;
	private JLabel img1,img2,name1,name2,weapon1,weapon2,power1_,power2_,agility1_,agility2_,speed1_,speed2_,defense1_,defense2_;
	private JTextArea console;
	Window(){
		ch1 = new Dwarf(1,"Manolo","ee");
		ch2 = new Dwarf(2,"Pepe","ee");
		choose = new JPanel();
		ch_character = new JButton("Choose Character");
		ch_character.addActionListener(new ChooseWarrior());
		ch_weapon = new JButton("Choose Weapon");
		ranking = new JButton("Ranking");
		choose.add(ch_character);
		choose.add(ch_weapon);
		choose.add(ranking);
		
		character1 = new JPanel();
		character1.setLayout(new BorderLayout());
		health1 = new JProgressBar(0,ch1.getHealth());
		health1.setValue(ch1.getHealth());
		health1.setStringPainted(true);
		health1.setForeground(Color.GREEN);
		
		img1 = new JLabel();
		
		stats1 = new JPanel();
		stats1.setLayout(new BorderLayout());
		name1 = new JLabel(ch1.getName(), SwingConstants.CENTER);
		weapon1 = new JLabel();
		
		habilities1 = new JPanel();
		habilities1.setLayout(new GridLayout(4,2));
		power1_ = new JLabel("Power");
		power1 = new JProgressBar(0,11);
		power1.setValue(ch1.getStrength());
		power1.setForeground(Color.BLUE);
		
		agility1_ = new JLabel("Agility");
		agility1 = new JProgressBar(0,7);
		agility1.setValue(ch1.getAgility());
		agility1.setForeground(Color.RED);
		
		speed1_ = new JLabel("Speed");
		speed1 = new JProgressBar(0,12);
		speed1.setValue(ch1.getSpeed());
		speed1.setForeground(Color.YELLOW);
		
		defense1_ = new JLabel("Defense");
		defense1 = new JProgressBar(0,4);
		defense1.setValue(ch1.getDefense());
		defense1.setForeground(Color.PINK);
		
		habilities1.add(power1_);
		habilities1.add(power1);
		habilities1.add(agility1_);
		habilities1.add(agility1);
		habilities1.add(speed1_);
		habilities1.add(speed1);
		habilities1.add(defense1_);
		habilities1.add(defense1);
		
		stats1.add(name1,BorderLayout.NORTH);
		stats1.add(habilities1,BorderLayout.EAST);
		stats1.add(weapon1, BorderLayout.WEST);
		
		character1.add(health1,BorderLayout.NORTH);
		character1.add(img1, BorderLayout.CENTER);
		character1.add(stats1,BorderLayout.SOUTH);
		
		character2 = new JPanel();
		character2.setLayout(new BorderLayout());
		health2 = new JProgressBar(0,ch2.getHealth());
		health2.setValue(ch2.getHealth());
		health2.setStringPainted(true);
		health2.setForeground(Color.GREEN);
		img2 = new JLabel();
		stats2 = new JPanel();
		stats2.setLayout(new BorderLayout());
		name2 = new JLabel(ch2.getName(), SwingConstants.CENTER);
		weapon2 = new JLabel();
		
		habilities2 = new JPanel();
		habilities2.setLayout(new GridLayout(4,2));
		power2_ = new JLabel("Power");
		power2 = new JProgressBar(0,11);
		power2.setValue(ch2.getStrength());
		power2.setForeground(Color.BLUE);
		
		agility2_ = new JLabel("Agility");
		agility2 = new JProgressBar(0,7);
		agility2.setValue(ch2.getAgility());
		agility2.setForeground(Color.RED);
		
		speed2_ = new JLabel("Speed");
		speed2 = new JProgressBar(0,12);
		speed2.setValue(ch2.getSpeed());
		speed2.setForeground(Color.YELLOW);
		
		defense2_ = new JLabel("Defense");
		defense2 = new JProgressBar(0,4);
		defense2.setValue(ch2.getDefense());
		defense2.setForeground(Color.PINK);

		
		habilities2.add(power2_);
		habilities2.add(power2);
		habilities2.add(agility2_);
		habilities2.add(agility2);
		habilities2.add(speed2_);
		habilities2.add(speed2);
		habilities2.add(defense2_);
		habilities2.add(defense2);
		
		stats2.add(name2,BorderLayout.NORTH);
		stats2.add(habilities2,BorderLayout.EAST);
		
		stats2.add(weapon2, BorderLayout.WEST);
		
		character2.add(health2,BorderLayout.NORTH);
		character2.add(img2, BorderLayout.CENTER);
		character2.add(stats2,BorderLayout.SOUTH);

		fight = new JPanel();
		fight.setLayout(new BorderLayout());
		fightButton = new JButton("Fight");
		clearConsole = new JButton("Clear Console");
		console = new JTextArea(10,800);
		console.setEditable(false);
		
		fight.add(fightButton,BorderLayout.WEST);
		fight.add(clearConsole,BorderLayout.EAST);
		fight.add(console,BorderLayout.SOUTH);
		
		this.add(choose,BorderLayout.NORTH);
		this.add(character1,BorderLayout.WEST);
		this.add(character2,BorderLayout.EAST);
		this.add(fight,BorderLayout.SOUTH);
		
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(200,300,800,800);
		this.setVisible(true);

	}
}
class WindowCharacters extends JFrame{
	private Warrior w;
	private int positionWarrior;
	private Warrior warriorSelected;
	WindowCharacters(){
		this.setLayout(new GridLayout(3,3));
        Toolkit mipantalla = Toolkit.getDefaultToolkit();
		WarriorContainer warriors = new WarriorContainer();
		Image img;
		Image dimg;
		ImageIcon icon;
		
		int i = 0;
		for (Warrior w : warriors.getWarriors()) {
			img = mipantalla.getImage(w.getUrl());
			dimg = img.getScaledInstance(100, 200, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			JButton b = new JButton(icon);
			if (w instanceof Human) {
				b.setBackground(Color.CYAN);
			}
			if (w instanceof Elf) {
				b.setBackground(Color.RED);
			}
			if (w instanceof Dwarf) {
				b.setBackground(Color.YELLOW);
			}
			WarriorButton wb = new WarriorButton(b,i);
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					positionWarrior = wb.getPosition();
					warriorSelected = warriors.getWarriors().get(positionWarrior);
				}	
			});
			this.add(b);
			i++;
		}
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(200,300,800,800);
		this.setVisible(true);
	}
	public Warrior getWarrior() {
		return warriorSelected;
	}
}
class ChooseWarrior implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		new WindowCharacters();
	}
}
class WarriorButton extends JButton{
	private JButton b;
	private int position;

	public WarriorButton() {
		super();
	}

	public WarriorButton(JButton b, int position) {
		super();
		this.b = b;
		this.position = position;
	}

	public JButton getB() {
		return b;
	}

	public void setB(JButton b) {
		this.b = b;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}
	
}
