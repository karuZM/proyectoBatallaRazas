import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class WarriorContainer {
	private ArrayList<Warrior> warriors;
	WarriorContainer(){
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
		String usuario = "root";
		String pass = "root";
		try {
			this.warriors = new ArrayList<Warrior>();
			//Cargar driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Crear conexion BBDD
			java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
			
			//Crear consulta
			String query = "select * from warriors";

			//Instanciar objeto de la clase Consulta
			Statement stmnt = conn.createStatement();
			
			//Ejecutar la consulta
			ResultSet rs = stmnt.executeQuery(query);
			
			while (rs.next()) {
				if(rs.getInt(4)==1) {
					Human h = new Human(rs.getInt(1),rs.getString(2),rs.getString(3));
					this.warriors.add(h);
				}
				if(rs.getInt(4)==2) {
					Elf e = new Elf(rs.getInt(1),rs.getString(2),rs.getString(3));
					this.warriors.add(e);
				}
				if(rs.getInt(4)==3) {
					Dwarf d = new Dwarf(rs.getInt(1),rs.getString(2),rs.getString(3));
					this.warriors.add(d);
				}
			}

			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver no se ha cargado correctamente!!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Conexión no creada correctamente!!");
		}
	}
	public ArrayList<Warrior> getWarriors() {
		return warriors;
	}
	public void setWarriors(ArrayList<Warrior> warriors) {
		this.warriors = warriors;
	}
	public Warrior getWarrior(int id) {
		Warrior warrior = null;
		for (Warrior w : warriors) {
			if (w.getId()==id) {
				warrior = w;
			}
		}
		return warrior;
	}
	public Warrior randomWarrior() {
		int n = (int) (Math.random()*8);
		Warrior w = this.warriors.get(n);
		return w;
	}

}
