import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class WeaponContainer {
	private ArrayList<Weapon> weapons;
	WeaponContainer(){
		String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
		String usuario = "root";
		String pass = "root";
		try {
			this.weapons = new ArrayList<Weapon>();
			//Cargar driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Crear conexion BBDD
			java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
			String query = "";
//			//Crear consulta
//			if(w instanceof Human) {
//				query = "select * from weapons where weapon_race like '%Human%'";
//			}
//			if(w instanceof Elf) {
//				query = "select * from weapons where weapon_race like '%Elf%'";
//			}
//			if(w instanceof Dwarf) {
//				query = "select * from weapons where weapon_race like '%Dwarf%'";
//			}
			query = "select * from weapons ";
			
			//Instanciar objeto de la clase Consulta
			Statement stmnt = conn.createStatement();
			
			//Ejecutar la consulta
			ResultSet rs = stmnt.executeQuery(query);
			
			while(rs.next()) {
				Weapon we = new Weapon(rs.getInt(1), rs.getString(2),rs.getInt(4),rs.getInt(5),rs.getString(3),rs.getString(6));
				weapons.add(we);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver no se ha cargado correctamente!!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Conexión no creada correctamente!!");
		}
	}
	public ArrayList<Weapon> getWeapons() {
		return weapons;
	}
	public void setWeapons(ArrayList<Weapon> weapons) {
		this.weapons = weapons;
	}
	public Weapon getRandomWeapon(Warrior w) {
		String raza = w.getClass().getSimpleName();
		ArrayList<Weapon> segunRaza = new ArrayList<Weapon>();
		for (Weapon weapon : weapons) {
			if (weapon.getClases().contains(raza)) {
				segunRaza.add(weapon);
			}
		}
		return segunRaza.get((int) (Math.random()*(segunRaza.size())));
//		int n = (int) (Math.random()*(weapons.size()-1));
//		Weapon w = weapons.get(n);
//		return w;
	}
	public Weapon getWeapon(int id) {
		Weapon weapon = null;
		for (Weapon w : weapons) {
			if (w.getId()==id) {
				weapon=w;
			}
		}
		return weapon;
	}
}
