
public abstract class Warrior {
	private int id;
	private String name;
	private int health;
	private int strength;
	private int speed;
	private int agility;
	private int defense;
	private String url;
	private Weapon weapon;
	public Warrior() {
		super();
	}
	public Warrior(int id, String name, int health, int strength, int speed, int agility, int defense, String url, Weapon weapon) {
		super();
		this.id = id;
		this.name = name;
		this.health = health;
		this.strength = strength;
		this.speed = speed;
		this.agility = agility;
		this.defense = defense;
		this.url = url;
		this.weapon = weapon;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getAgility() {
		return agility;
	}
	public void setAgility(int agility) {
		this.agility = agility;
	}
	public int getDefense() {
		return defense;
	}
	public void setDefense(int defense) {
		this.defense = defense;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Weapon getWeapon() {
		return weapon;
	}
	public void setWeapon(Weapon weapon) {
		this.weapon = weapon;
	}
	
	public String attack(Warrior c) {
		String result = null;
		int n1 = (int)(Math.random()*100);
		if((this.getAgility()*10) > n1) {
			int n2 = (int)(Math.random()*50);
			if(c.getAgility()>n2) {
				result = c.getName()+ "has avoid the attack!";
			}
			else {
				int damage = this.getStrength()+this.getWeapon().getStrength()-c.getDefense();
				int newHealth = c.getHealth()-damage;
				c.setHealth(newHealth);
				result = c.getName()+"'s health has decreased in "+damage+" points";
			}
		}
		else {
			result = this.getName()+" has failed his attack!";
		}
		return result;
	}
	
}

