import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInsert {
	//Class used to insert data to the database
	DatabaseInsert() {
    }

    public void insertplayer(String usrname) {
    	//Method that inserts the player with the username introduced
        String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            String update = "INSERT INTO players (player_name) VALUES ('" + usrname + "');";

            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
    }
    public void insertRanking(int warrior_id) {
    	//Method that inserts the ranking with the warrior that the user has selected. 
    	//The total points are 0 at the beginning 
        String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            String update = "INSERT INTO ranking (player_id,total_points,warrior_id) VALUES ((select max(player_id) from players),0,"+warrior_id+");";

            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
    }
    public void insertBattle(int warriorID, int weaponID, int opponentID, int opponentWeaponID) {
    	//Method that inserts the battle once it has finished
    	//The points are 0 at the beginning
    	String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            String update = "INSERT INTO battle (player_id,warrior_id,warrior_weapon_id,opponent_id,"
            		+ "opponent_weapon_id,injuries_caused,injuries_suffered,battle_points) VALUES ((select max(player_id) from players),"+
            		warriorID+","+weaponID+","+opponentID+","+opponentWeaponID+",0,0,0);";

            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
    }
    public void updatePoints(int points, int injuriesCaused, int injuriesSuffered) {
    	//Method to update the points of a battle if the user wins
    	String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            Statement stmnt = conn.createStatement();

            String query = "select max(battle_id) from battle";
            ResultSet rs = stmnt.executeQuery(query);
            rs.next();
            int id = rs.getInt(1);
            
            String update = "UPDATE battle set battle_points = "+points+",injuries_caused"
            		+ " = "+injuriesCaused+",injuries_suffered = "+injuriesSuffered+" where battle_id="+id+";";

			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
    }
    public void updateTotalPoints(int totalPoints) {
    	//Method to update the total points once the user stops playing, loses or changes his warrior
    	String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            Statement stmnt = conn.createStatement();

            String query = "select max(ranking_id) from ranking";
            ResultSet rs = stmnt.executeQuery(query);
            rs.next();
            int id = rs.getInt(1);
            
            String update = "UPDATE ranking set total_points = "+totalPoints+" where ranking_id="+id+";";

			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("Connection not created correctly!!");
        }
    }
}
