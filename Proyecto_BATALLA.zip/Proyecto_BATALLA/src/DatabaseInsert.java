import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInsert {
	DatabaseInsert() {
    }

    public void insertplayer(String usrname) {
        String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            // Cargar driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Crear conexion BBDD y query que ejecutaremos
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            String update = "INSERT INTO players (player_name) VALUES ('" + usrname + "');";

            // Instanciar objeto de la clase Consulta
            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("Connection not created correctly!!");
        }
    }
    public void insertRanking(int warrior_id) {
        String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            // Cargar driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Crear conexion BBDD y query que ejecutaremos
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            String update = "INSERT INTO ranking (player_id,total_points,warrior_id) VALUES ((select max(player_id) from players),0,"+warrior_id+");";

            // Instanciar objeto de la clase Consulta
            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("Connection not created correctly!!");
        }
    }
    public void insertBattle(int warriorID, int weaponID, int opponentID, int opponentWeaponID) {
    	String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            // Cargar driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Crear conexion BBDD y query que ejecutaremos
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            String update = "INSERT INTO battle (player_id,warrior_id,warrior_weapon_id,opponent_id,"
            		+ "opponent_weapon_id,battle_points) VALUES ((select max(player_id) from players),"+
            		warriorID+","+weaponID+","+opponentID+","+opponentWeaponID+",0);";

            // Instanciar objeto de la clase Consulta
            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("Connection not created correctly!!");
        }
    }
    public void insertRound(int injuriesCaused, int injuriesSuffered, int warriorID) {
    	String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            // Cargar driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Crear conexion BBDD y query que ejecutaremos
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            String update = "INSERT INTO rounds(battle_id,injuries_caused,injuries_suffered,player_id,warrior_id)VALUES"
            		+ "((select max(battle_id) from battle),"+injuriesCaused+","+injuriesSuffered+",(select max(player_id) from players),"+warriorID+");";

            // Instanciar objeto de la clase Consulta
            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("Connection not created correctly!!");
        }
    }
    public void updatePoints(int points) {
    	String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            // Cargar driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            

            // Crear conexion BBDD y query que ejecutaremos
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            Statement stmnt = conn.createStatement();

            String query = "select max(battle_id) from battle";
            ResultSet rs = stmnt.executeQuery(query);
            rs.next();
            int id = rs.getInt(1);
            
            String update = "UPDATE battle set battle_points = "+points+" where battle_id="+id+";";

			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("Connection not created correctly!!");
        }
    }
    public void updateTotalPoints(int totalPoints) {
    	String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root";
        try {
            // Cargar driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            

            // Crear conexion BBDD y query que ejecutaremos
            java.sql.Connection conn = DriverManager.getConnection(urlDatos, usuario, pass);
            Statement stmnt = conn.createStatement();
            
            String update = "UPDATE ranking set total_points = "+totalPoints+" where player_id=(select max(player_id) from players);";

			stmnt.executeUpdate(update);
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("Driver was not loaded correctly!!");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("Connection not created correctly!!");
        }
    }
}
