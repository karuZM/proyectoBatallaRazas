import java.util.ArrayList;

public class WeaponContainer {
	//Class that contains an arraylist with all the weapons
	private ArrayList<Weapon> weapons = new ArrayList<Weapon>();
	WeaponContainer(){
		new DatabaseInsert().populateWeaponContainer(this);
	}
	public ArrayList<Weapon> getWeapons() {
		return weapons;
	}
	public Weapon getRandomWeapon(Warrior w) {
		//Method that returns a random weapon depending on what warrior you put as parameter
		String race = w.getClass().getSimpleName();
		ArrayList<Weapon> weaponsRace = new ArrayList<Weapon>();
		for (Weapon weapon : weapons) {
			if (weapon.getClases().contains(race)) {
				weaponsRace.add(weapon);
			}
		}
		return weaponsRace.get((int) (Math.random()*(weaponsRace.size())));
	}
	public Weapon getWeapon(int id) {
		//Method that returns the weapon with the id introduced
		Weapon weapon = null;
		for (Weapon w : weapons) {
			if (w.getId()==id) {
				weapon=w;
			}
		}
		return weapon;
	}
	public void addWeapon(Weapon w) {
		//Method to add a weapon to the arraylist
		this.weapons.add(w);
	}
}
