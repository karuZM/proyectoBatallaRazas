import java.util.ArrayList;

public class WarriorContainer {
	//Class that contains an arraylist with all the warriors
	private ArrayList<Warrior> warriors = new ArrayList<Warrior>();
	WarriorContainer(){
		(new DatabaseInsert()).populateWarriorContainer(this);
	}
	public ArrayList<Warrior> getWarriors() {
		return warriors;
	}
	public Warrior getWarrior(int id) {
		//Method that returns the warrior with the id introduced
		Warrior warrior = null;
		for (Warrior w : warriors) {
			if (w.getId()==id) {
				warrior = w;
			}
		}
		return warrior;
	}
	public Warrior randomWarrior() {
		//Method that returns a random warrior
		int n = (int) (Math.random()*8);
		Warrior w = this.warriors.get(n);
		return w;
	}
	public void addWarrior(Warrior w) {
		//Method to add a warrior to the arraylist
		this.warriors.add(w);
	}

}
