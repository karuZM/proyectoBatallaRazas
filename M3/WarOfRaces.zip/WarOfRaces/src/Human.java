
public class Human extends Warrior{
//Human class. 
	public Human() {
		super();
	}

	public Human(int id, String name, String url) {
		super(id, name, 50, 5, 5, 6, 3, url,null);
	}
	

}
