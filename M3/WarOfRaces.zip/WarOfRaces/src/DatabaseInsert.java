import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DatabaseInsert {
	//Class used to connect the database
	private String urlDatos = "jdbc:mysql://localhost/guerraRazas?serverTimezone=UTC";
	private String usuario = "root";
	private String pass = "root";
    java.sql.Connection conn;
	DatabaseInsert() {
		//We connect the database in the constructor of the class
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(urlDatos, usuario, pass);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    public void insertplayer(String usrname) {
    	//Method that inserts the player with the username introduced
        try {
            String update = "INSERT INTO players (player_name) VALUES ('" + usrname + "');";

            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
    }
    public void insertRanking(int warrior_id) {
    	//Method that inserts the ranking with the warrior that the user has selected. 
    	//The total points are 0 at the beginning 
        try {
            String update = "INSERT INTO ranking (player_id,total_points,warrior_id) VALUES ((select max(player_id) from players),0,"+warrior_id+");";

            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
    }
    public void insertBattle(int warriorID, int weaponID, int opponentID, int opponentWeaponID,
    		int points, int injuriesCaused, int injuriesSuffered) {
    	//Method that inserts the battle once it has finished
    	//The points are 0 at the beginning
        try {
            String update = "INSERT INTO battle (player_id,warrior_id,warrior_weapon_id,opponent_id,"
            		+ "opponent_weapon_id,injuries_caused,injuries_suffered,battle_points) VALUES ((select max(player_id) from players),"+
            		warriorID+","+weaponID+","+opponentID+","+opponentWeaponID+","+injuriesCaused+
            		","+injuriesSuffered+","+points+");";

            Statement stmnt = conn.createStatement();
			stmnt.executeUpdate(update);
            
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
    }
    
    public void updateTotalPoints(int totalPoints) {
    	//Method to update the total points once the user stops playing, loses or changes his warrior
        try {
            Statement stmnt = conn.createStatement();

            String query = "select max(ranking_id) from ranking";
            ResultSet rs = stmnt.executeQuery(query);
            rs.next();
            int id = rs.getInt(1);
            
            String update = "UPDATE ranking set total_points = "+totalPoints+" where ranking_id="+id+";";

			stmnt.executeUpdate(update);
            
        } catch (SQLException e) {
            System.out.println("Connection not created correctly!!");
        }
    }
   public void populateWarriorContainer(WarriorContainer wc) {
		//Method to add all the warriors from the database to the WarriorContainer class
    		try {
    			String query = "select * from warriors";

    			Statement stmnt = conn.createStatement();
    			
    			ResultSet rs = stmnt.executeQuery(query);
    			
    			while (rs.next()) {
    				if(rs.getInt(4)==1) {
    					Human h = new Human(rs.getInt(1),rs.getString(2),rs.getString(3));
    					wc.addWarrior(h);
    				}
    				if(rs.getInt(4)==2) {
    					Elf e = new Elf(rs.getInt(1),rs.getString(2),rs.getString(3));
    					wc.addWarrior(e);
    				}
    				if(rs.getInt(4)==3) {
    					Dwarf d = new Dwarf(rs.getInt(1),rs.getString(2),rs.getString(3));
    					wc.addWarrior(d);
    				}
    			}
    			
    		} catch (SQLException e) {
    			System.out.println("Conexión no creada correctamente!!");
    		}
    }

public void populateWeaponContainer(WeaponContainer wc) {
	//Method to add all the weapons from the database to the WeaponContainer class
	try {
		String query = "select * from weapons";

		Statement stmnt = conn.createStatement();
		
		ResultSet rs = stmnt.executeQuery(query);
		
		while(rs.next()) {
			wc.addWeapon( new Weapon(rs.getInt(1), rs.getString(2),rs.getInt(4),rs.getInt(5),rs.getString(3),rs.getString(6)));

		}

		
	} catch (SQLException e) {
		System.out.println("ConexiÃ³n no creada correctamente!!");
	}
}
public ArrayList <String[]> globalRanking() {
	//Method that returns the 5 players with the most points
	ArrayList<String[]> ranking = new ArrayList<String[]>();
	try {
		String query = "select players.player_name as \"player name\",ranking.total_points as \"total points\",warriors.warrior_name as \"warrior\" \n"
				+ "from ranking\n"
				+ "inner join players on players.player_id = ranking.player_id\n"
				+ "inner join warriors on warriors.warrior_id = ranking.warrior_id\n"
				+ "order by ranking.total_points desc limit 5;";

		Statement stmnt = conn.createStatement();
		
		ResultSet rs = stmnt.executeQuery(query);
		
		while(rs.next()) {
			String [] row = new String[3];
			row[0] = rs.getString(1);
			row[1] = rs.getInt(2)+"";
			row[2] = rs.getString(3);
			ranking.add(row);
		}
		
	} catch (SQLException e) {
		System.out.println("Conexión no creada correctamente!!");
	}
	return ranking;
}
public ArrayList <String[]> defeatedEnemies(){
	//Method that returns the 5 players with the most defeated enemies
	ArrayList<String[]> ranking = new ArrayList<String[]>();
	try {
		String query = "select players.player_name,count(battle.battle_id) as \"defeated enemies\" from battle\n"
				+ "inner join players on players.player_id = battle.player_id\n"
				+ "where  battle.battle_points > 0\n"
				+ "group by battle.player_id\n"
				+ "order by count(battle.battle_id) desc limit 5;";

		Statement stmnt = conn.createStatement();
		
		ResultSet rs = stmnt.executeQuery(query);
		
		while(rs.next()) {
			String [] row = new String[2];
			row[0] = rs.getString(1);
			row[1] = rs.getInt(2)+"";
			ranking.add(row);
		}
		
	} catch (SQLException e) {
		System.out.println("Conexión no creada correctamente!!");
	}
	return ranking;
}
public ArrayList <String[]> moreUsedWarriors(){
	//Method that returns the 5 most used warriors
	ArrayList<String[]> ranking = new ArrayList<String[]>();
	try {
		String query = "select warriors.warrior_name, count(ranking.warrior_id) from ranking\n"
				+ "inner join warriors on ranking.warrior_id = warriors.warrior_id\n"
				+ "group by ranking.warrior_id\n"
				+ "order by count(ranking.warrior_id) desc limit 5;";

		Statement stmnt = conn.createStatement();
		
		ResultSet rs = stmnt.executeQuery(query);
		
		while(rs.next()) {
			String [] row = new String[2];
			row[0] = rs.getString(1);
			row[1] = rs.getInt(2)+"";
			ranking.add(row);
		}
		
	} catch (SQLException e) {
		System.out.println("Conexión no creada correctamente!!");
	}
	return ranking;
}
public ArrayList <String[]> moreUsedWeapons(){
	//Method that returns the 5 most used weapons
	ArrayList<String[]> ranking = new ArrayList<String[]>();
	try {
		String query = "select weapons.weapon_name, count(battle.warrior_weapon_id) from battle\n"
				+ "inner join weapons on battle.warrior_weapon_id = weapons.weapon_id\n"
				+ "group by battle.warrior_weapon_id\n"
				+ "order by count(battle.warrior_weapon_id) desc limit 5;";

		Statement stmnt = conn.createStatement();
		
		ResultSet rs = stmnt.executeQuery(query);
		
		while(rs.next()) {
			String [] row = new String[2];
			row[0] = rs.getString(1);
			row[1] = rs.getInt(2)+"";
			ranking.add(row);
		}
		
	} catch (SQLException e) {
		System.out.println("Conexión no creada correctamente!!");
	}
	return ranking;
}


}
