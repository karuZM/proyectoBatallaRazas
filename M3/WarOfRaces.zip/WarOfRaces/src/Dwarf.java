
public class Dwarf extends Warrior{
//Dwarf class
	public Dwarf() {
		super();
	}

	public Dwarf(int id, String name, String url) {
		super(id, name, 60, 6, 3, 5, 4, url, null);
	}
	

}
