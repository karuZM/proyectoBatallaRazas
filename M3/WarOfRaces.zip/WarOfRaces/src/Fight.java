import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;

public class Fight {

	public static void main(String[] args) {
		new Window0();
	}
}

class Window0 extends JFrame {
	// Window where we ask for an username, and controls it isn't null
	private String name;
	private JPanel buttons, usernamep;
	private JButton b1, b2;
	private JTextField username;
	private JLabel title, user, imgGame;
	private JPanel panelEtiqueta = new JPanel();

	public Window0() {
		getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		title = new JLabel("Battle of Races", SwingConstants.CENTER);
		title.setFont(new Font("arial", Font.BOLD, 70));
		title.setForeground(Color.white);
		title.setBackground(Color.BLACK);

		add(title);
		// add(logo);
		Image img;

		imgGame = new JLabel();
		imgGame.setBorder(BorderFactory.createBevelBorder(10));

		imgGame.setAlignmentX(RIGHT_ALIGNMENT);
		Toolkit mipantalla = Toolkit.getDefaultToolkit();
		img = mipantalla.getImage("ImagenesProjecto/Extra/iconwindow0.png");
		imgGame.setIcon(new ImageIcon(img.getScaledInstance(200, 200, Image.SCALE_SMOOTH)));
		imgGame.setBackground(Color.black);
		imgGame.setBackground(Color.red);

		panelEtiqueta.setLayout(new BoxLayout(panelEtiqueta, BoxLayout.X_AXIS));
		panelEtiqueta.add(Box.createGlue());
		panelEtiqueta.add(imgGame);
		panelEtiqueta.add(Box.createGlue());
		panelEtiqueta.setBackground(Color.black);

		add(panelEtiqueta);

		user = new JLabel("Enter your username:");
		user.setForeground(Color.white);
		buttons = new JPanel();
		buttons.setBackground(Color.BLACK);
		b1 = new JButton("PLAY");
		b2 = new JButton("EXIT");
		b1.setBackground(Color.white);
		b2.setBackground(Color.white);
		usernamep = new JPanel();
		usernamep.setLayout(new FlowLayout());
		usernamep.setBackground(Color.BLACK);
		username = new JTextField(40);
		username.setForeground(Color.GRAY);
		username.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
			}

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					start();
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
			}

		});

		usernamep.add(user);
		usernamep.add(username);
		buttons.add(b1);
		buttons.add(b2);
		add(usernamep);
		add(buttons);

		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Listener where we create the main window, and control the username isn't null
				// and it's not longer than 50 characters
				start();

			}
		});

		b2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Exit button
				System.exit(0);

			}

		});
		Toolkit window = Toolkit.getDefaultToolkit();
		Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
		setIconImage(icon);
		getContentPane().setBackground(Color.BLACK);
		setSize(900, 500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void start() {
		//Method to control that the username is ok and start the game
		name = username.getText();
		if (name.equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Enter a username");
		} else if (name.length() > 50) {
			JOptionPane.showMessageDialog(null, "The username can't be longer than 50 characters");
		} else if (name.contains("'") | name.contains("\"")) {
			JOptionPane.showMessageDialog(null, "The username can't contain \" or '");
		} else {
			DatabaseInsert ins = new DatabaseInsert();
			ins.insertplayer(name);
			new Window(name);
			dispose();
		}
		username.setText("");
	}

}

class Window extends JFrame implements ActionListener {
	// Main window, where we have 2 panels that contain a warrior and their stats.
	// We also have a panel in the center with a vs image painted and the console
	// that shows what happens in the battle
	// We also create boolean attributes that we'll use to control the battle and
	// the inserts in the database
	private WarriorContainer warriors = new WarriorContainer();
	private ImageComponent vs = new ImageComponent("ImagenesProjecto/Extra/vs.png");
	private Ch1 ch1 = new Ch1();
	private Ch1 ch2 = new Ch1();
	private JPanel choose, fight_buttons, fight;
	private JButton ch_character, ch_weapon, ranking, ch_background, fightButton, clearConsole;
	private JTextArea console;
	private WeaponContainer wepCont_w2 = new WeaponContainer();
	private int round = 0;
	private boolean battle = false;
	private Ch1[] fightingWarriors = new Ch1[2];
	private boolean win;
	private int total_points, initialHealth, initialOpponentHealth;
	private boolean rankingInserted = false;

	Window(String username) {
		JPanel top = new JPanel();
		top.setLayout(new BorderLayout());
		JLabel userInfo = new JLabel(username + "     -     CPU", SwingConstants.CENTER);
		userInfo.setForeground(Color.white);
		top.setBackground(Color.black);
		top.add(userInfo, BorderLayout.NORTH);
		ch2.setWarrior(warriors.randomWarrior());
		ch2.setWeapon(wepCont_w2.getRandomWeapon(ch2.getWarrior()));
		choose = new JPanel();
		choose.setBackground(Color.BLACK);
		ch_character = new JButton("Choose Character");
		ch_character.setBackground(Color.WHITE);
		ch_character.addActionListener(this);
		ch_weapon = new JButton("Choose Weapon");
		ch_weapon.setBackground(Color.WHITE);
		ch_weapon.addActionListener(this);
		ranking = new JButton("Ranking");
		ranking.setBackground(Color.WHITE);
		ranking.addActionListener(this);
		ch_background = new JButton("Change Background");
		ch_background.setBackground(Color.WHITE);
		ch_background.addActionListener(this);
		choose.add(ch_character);
		choose.add(ch_weapon);
		choose.add(ch_background);
		choose.add(ranking);
		top.add(choose, BorderLayout.SOUTH);

		fight = new JPanel();
		fight_buttons = new JPanel();
		fight_buttons.setBackground(Color.BLACK);
		fight.setLayout(new BorderLayout());
		fightButton = new JButton("Fight");
		fightButton.setBackground(Color.WHITE);
		fightButton.addActionListener(this);
		clearConsole = new JButton("Clear Console");
		clearConsole.setBackground(Color.WHITE);
		clearConsole.addActionListener(this);
		fight_buttons.add(fightButton);
		fight_buttons.add(clearConsole);
		console = new JTextArea(10, 800);
		console.setBackground(Color.BLACK);
		console.setForeground(Color.WHITE);
		JScrollPane sp = new JScrollPane(console);
		console.setEditable(false);

		fight.add(fight_buttons, BorderLayout.NORTH);
		fight.add(sp, BorderLayout.SOUTH);

		this.add(top, BorderLayout.NORTH);
		this.add(vs, BorderLayout.CENTER);
		this.add(ch1, BorderLayout.WEST);
		this.add(ch2, BorderLayout.EAST);
		this.add(fight, BorderLayout.SOUTH);
		
		Toolkit window = Toolkit.getDefaultToolkit();
		Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
		setIconImage(icon);

		this.setSize(810, 740);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);

		try {
			FondoSwing fondo = new FondoSwing(ImageIO.read(new File("ImagenesProjecto/Extra/FondoBosque.jpg")));
			JPanel panel = (JPanel) this.getContentPane();
			panel.setBorder(fondo);
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void setBackgroundA(String url) {
		//Method that changes the background
		try {
			FondoSwing fondo = new FondoSwing(ImageIO.read(new File(url)));
			JPanel panel = (JPanel) this.getContentPane();
			panel.setBorder(fondo);
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	public class FondoSwing implements Border {
		// Class that puts an image at the background
		private BufferedImage mImagen = null;

		public FondoSwing(BufferedImage pImagen) {
			mImagen = pImagen;
		}

		@Override
		public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
			if (mImagen != null) {
				g.drawImage(mImagen, 0, 0, width, height, null);
			}
		}

		@Override
		public Insets getBorderInsets(Component c) {
			return new Insets(0, 0, 0, 0);
		}

		@Override
		public boolean isBorderOpaque() {
			return true;
		}
	}

	class Ch1 extends JPanel {
		// Panel that contains a warrior that will fight. It shows the stats, the
		// health, and the image of the warrior
		private Warrior w = null;
		private JPanel habilities1, stats1;
		private JLabel name1, weapon1, power1_, agility1_, speed1_, defense1_;
		private JProgressBar health1, power1, agility1, speed1, defense1;
		private JLabel etiquetaWarrior;
		private Image img, dimg;
		private ImageIcon icon;
		private Toolkit mipantalla = Toolkit.getDefaultToolkit();

		Ch1() {
			this.setLayout(new BorderLayout());
			//We create all the components
			health1 = new JProgressBar(0, 0);
			health1.setValue(0);
			health1.setStringPainted(true);
			
			etiquetaWarrior = new JLabel();
			
			habilities1 = new JPanel();
			habilities1.setLayout(new GridLayout(4, 2));
			habilities1.setOpaque(false);
			
			stats1 = new JPanel();
			stats1.setBackground(new Color(247, 198, 118));
			stats1.setLayout(new BorderLayout());
			
			name1 = new JLabel("", SwingConstants.CENTER);
			name1.setForeground(Color.black);
			name1.setBorder(BorderFactory.createLineBorder(Color.black, 1));
			
			weapon1 = new JLabel();
			weapon1.setBorder(BorderFactory.createLineBorder(Color.black, 1));
			
			power1_ = new JLabel("Power");
			power1_.setForeground(Color.black);
			
			agility1_ = new JLabel("Agility");
			agility1_.setForeground(Color.black);
			
			speed1_ = new JLabel("Speed");
			speed1_.setForeground(Color.black);
			
			defense1_ = new JLabel("Defense");
			defense1_.setForeground(Color.black);
			
			power1 = new JProgressBar(0, 11);
			power1.setValue(0);
			power1.setForeground(Color.BLUE);
			power1.setBorder(BorderFactory.createLineBorder(Color.black, 1));

			agility1 = new JProgressBar(0, 7);
			agility1.setValue(0);
			agility1.setForeground(Color.RED);
			agility1.setBorder(BorderFactory.createLineBorder(Color.black, 1));

			speed1 = new JProgressBar(0, 12);
			speed1.setValue(0);
			speed1.setForeground(Color.YELLOW);
			speed1.setBorder(BorderFactory.createLineBorder(Color.black, 1));

			defense1 = new JProgressBar(0, 4);
			defense1.setValue(0);
			defense1.setForeground(Color.PINK);
			defense1.setBorder(BorderFactory.createLineBorder(Color.black, 1));
			
			habilities1.add(power1_);
			habilities1.add(power1);
			habilities1.add(agility1_);
			habilities1.add(agility1);
			habilities1.add(speed1_);
			habilities1.add(speed1);
			habilities1.add(defense1_);
			habilities1.add(defense1);

			stats1.add(name1, BorderLayout.NORTH);
			stats1.add(habilities1, BorderLayout.EAST);
			stats1.add(weapon1, BorderLayout.WEST);
			
			Toolkit window = Toolkit.getDefaultToolkit();
			Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
			setIconImage(icon);

			this.setOpaque(false);
			this.add(health1, BorderLayout.NORTH);
			this.add(etiquetaWarrior, BorderLayout.CENTER);
			this.add(stats1, BorderLayout.SOUTH);

			this.setVisible(true);

		}

		public void setWarrior(Warrior warrior) {
			// Method to change the warrior and set the stats
			this.w = warrior;
			Toolkit mipantalla = Toolkit.getDefaultToolkit();
			Image img;
			if (this.w != null) {
				img = mipantalla.getImage(this.w.getUrl());
				etiquetaWarrior.setIcon(new ImageIcon(img.getScaledInstance(300, 300, Image.SCALE_SMOOTH)));
				name1.setText(this.w.getName());
				name1.setToolTipText(w.getName());
				health1.setMaximum(this.w.getHealth());
			}
			else {
				etiquetaWarrior.setIcon(null);
				name1.setText("");
			}
			setWeaponImage();
			setStats();
			setHealth();
		}

		public Warrior getWarrior() {
			return w;

		}

		public void setStats() {
			// Method that set the stats of the warrior with progress bars
			if (this.w != null) {

				if (this.w.getWeapon() != null) {
					speed1.setValue(this.w.getSpeed() + this.w.getWeapon().getSpeed());
					power1.setValue(this.w.getStrength() + this.w.getWeapon().getStrength());
				} else {
					power1.setValue(this.w.getStrength());
					speed1.setValue(this.w.getSpeed());
				}

				agility1.setValue(this.w.getAgility());
				defense1.setValue(this.w.getDefense());
			}

		}

		public void setWeaponImage() {
			// Method that puts the correct image of the weapon, and controls if it's null
			if (this.w == null) {
				img = mipantalla.getImage("ImagenesProjecto/Extra/cross.png");
				dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				weapon1.setIcon(icon);
			} else if (this.w.getWeapon() == null) {
				img = mipantalla.getImage("ImagenesProjecto/Extra/cross.png");
				dimg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				weapon1.setIcon(icon);
			} else {
				Image img = mipantalla.getImage(this.w.getWeapon().getUrl());
				weapon1.setIcon(new ImageIcon(img.getScaledInstance(50, 50, Image.SCALE_SMOOTH)));
			}
		}

		public void setWeapon(Weapon weap) {
			this.w.setWeapon(weap);
			setWeaponImage();
			setStats();
		}

		public void setHealth() {
			// Method that changes the health progress bar
			if (this.w != null) {
				health1.setValue(this.w.getHealth());
				health1.setString(this.w.getHealth()+"");
				if (health1.getValue() > health1.getMaximum() / 2) {
					health1.setForeground(Color.green);
				} else {
					if (health1.getValue() > health1.getMaximum() / 5) {
						health1.setForeground(Color.orange);
					} else {
						health1.setForeground(Color.red);
					}
				}
			}

		}

		public void resetStats() {
			// Method used when a battle ends, to reset the stats
			if (this.w instanceof Human) {
				this.w.setHealth(50);
			}
			if (this.w instanceof Elf) {
				this.w.setHealth(40);
			}
			if (this.w instanceof Dwarf) {
				this.w.setHealth(60);
			}
			this.w.setWeapon(null);
			setStats();
			setWeaponImage();
			setHealth();
		}

	}

	class WindowBackgrounds extends JFrame implements ActionListener {
		//The button is the one created down below
		private BackgroundButton b1, b2, b3, b4;

		WindowBackgrounds() {
			this.setLayout(new GridLayout(2, 2));
			
			Image img, dimg;
			ImageIcon icon;
			
			img = Toolkit.getDefaultToolkit().getImage("ImagenesProjecto/Extra/FondoBosque.jpg");
			dimg = img.getScaledInstance(400, 350, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			b1 = new BackgroundButton(icon, "ImagenesProjecto/Extra/FondoBosque.jpg");
			
			img = Toolkit.getDefaultToolkit().getImage("ImagenesProjecto/Extra/Paramo.jpg");
			dimg = img.getScaledInstance(400, 350, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			b2 = new BackgroundButton(icon, "ImagenesProjecto/Extra/Paramo.jpg");
			
			img = Toolkit.getDefaultToolkit().getImage("ImagenesProjecto/Extra/Estatuas.jpg");
			dimg = img.getScaledInstance(400, 350, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			b3 = new BackgroundButton(icon, "ImagenesProjecto/Extra/Estatuas.jpg");
			
			img = Toolkit.getDefaultToolkit().getImage("ImagenesProjecto/Extra/Lava.png");
			dimg = img.getScaledInstance(400, 350, Image.SCALE_SMOOTH);
			icon = new ImageIcon(dimg);
			b4 = new BackgroundButton(icon, "ImagenesProjecto/Extra/Lava.png");
			
			this.add(b1);
			this.add(b2);
			this.add(b3);
			this.add(b4);
			
			b4.addActionListener(this);
			b3.addActionListener(this);
			b2.addActionListener(this);
			b1.addActionListener(this);
			
			Toolkit window = Toolkit.getDefaultToolkit();
			Image icon1 = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
			setIconImage(icon1);

			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setSize(800, 740);
			this.setResizable(false);
			this.setLocationRelativeTo(null);
			this.setVisible(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			String imgUrl = ((BackgroundButton) (e.getSource())).getUrl();
			setBackgroundA(imgUrl);
			dispose();
		}
	}

	class WindowCharacters extends JFrame implements ActionListener {
		// Window that appears when the user press the button of choose character
		// It appears nine buttons with the image of the warriors on them
		private JFrame myFrame;
		private WarriorContainer warriors;

		WindowCharacters() {
			myFrame = new JFrame();
			myFrame.setLayout(new GridLayout(3, 3));
			Toolkit mipantalla = Toolkit.getDefaultToolkit();
			warriors = new WarriorContainer();
			Image img;
			Image dimg;
			ImageIcon icon;
			for (Warrior w : warriors.getWarriors()) {
				img = mipantalla.getImage(w.getUrl());
				dimg = img.getScaledInstance(100, 200, Image.SCALE_SMOOTH);
				icon = new ImageIcon(dimg);
				//The button is the one created down below
				WarriorButton wb = new WarriorButton(icon, w.getId(), w.getName());
				if (w instanceof Human) {
					wb.setBackground(new Color(177, 193, 230));
				}
				if (w instanceof Elf) {
					wb.setBackground(new Color(185, 215, 150));
				}
				if (w instanceof Dwarf) {
					wb.setBackground(new Color(223, 165, 165));
				}
				wb.addActionListener(this);
				myFrame.add(wb);
			}
			
			Toolkit window = Toolkit.getDefaultToolkit();
			Image icon1 = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
			setIconImage(icon1);

			myFrame.setResizable(false);
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setSize(800, 740);
			myFrame.setLocationRelativeTo(null);
			myFrame.setVisible(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// Listener that changes the warrior of the panel 1 using a personalized button
			int idWarrior = ((WarriorButton) (e.getSource())).getID();
			Warrior warriorSelected = warriors.getWarrior(idWarrior);
			ch1.setWarrior(warriorSelected);
			myFrame.dispose();
		}
	}

	class WindowWeapons extends JFrame implements ActionListener, WindowListener {
		// Window that appears when the user press the button of choose character
		// It will appear the weapons that the warrior selected can use
		private JFrame myFrame;
		private WeaponContainer weapCont = new WeaponContainer();

		WindowWeapons(Warrior w) {
			myFrame = new JFrame();
			myFrame.setLayout(new GridLayout(3, 3));
			Toolkit mipantalla = Toolkit.getDefaultToolkit();
			ImageIcon icon;
			for (Weapon weapon : weapCont.getWeapons()) {
				// We control what weapon can be shown with the WeaponContainer class
				if (weapon.getClases().contains(w.getClass().getSimpleName())) {
					icon = new ImageIcon(
							mipantalla.getImage(weapon.getUrl()).getScaledInstance(100, 200, Image.SCALE_SMOOTH));
					//The button is the one created down below
					WeaponButton wb = new WeaponButton(icon, weapon.getId(), weapon.getName());
					wb.addActionListener(this);
					wb.setBackground(Color.white);
					myFrame.add(wb);
				}
			}
			
			Toolkit window = Toolkit.getDefaultToolkit();
			Image icon1 = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
			setIconImage(icon1);
			
			myFrame.setResizable(false);
			myFrame.addWindowListener(this);
			myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			myFrame.setSize(800, 740);
			myFrame.setLocationRelativeTo(null);
			myFrame.setVisible(true);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// Listener that changes the weapon of the warrior selected
			int idWeapon = ((WeaponButton) (e.getSource())).getId();
			Weapon weaponSelected = weapCont.getWeapon(idWeapon);
			ch1.setWeapon(weaponSelected);
			myFrame.dispose();
		}

		@Override
		public void windowOpened(WindowEvent e) {}

		@Override
		public void windowClosing(WindowEvent e) {}

		@Override
		public void windowClosed(WindowEvent e) {}

		@Override
		public void windowIconified(WindowEvent e) {}

		@Override
		public void windowDeiconified(WindowEvent e) {}

		@Override
		public void windowActivated(WindowEvent e) {}

		@Override
		public void windowDeactivated(WindowEvent e) {
			myFrame.dispose();
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == ch_background) {
			//The user chooses a background. If the battle has started, he won't be able to change it
			if(battle) {
				JOptionPane.showMessageDialog(null, "You can't change the background in the middle of a battle!");
			}
			else {
			new WindowBackgrounds();
			}
		}
		// We control the buttons of the main Window
		if (e.getSource() == ranking) {
			// Ranking button. We create the ranking window
			new WindowRanking();
		}
		if (e.getSource() == ch_character) {
			// The user chooses the warrior. Once he has started a fight
			if (battle) {
				JOptionPane.showMessageDialog(null, "You can't change your warrior in the middle of a battle!");
			} else if (rankingInserted) {
				//If he changes the character after a battle has ended, we advise that his points will be reseted
				int opt = JOptionPane.showConfirmDialog(null,
						"If you change your warrior, you'll reset your points. You want to do it?");
				if (opt == 0) {
					rankingInserted = false;
					DatabaseInsert updTotPoints = new DatabaseInsert();
					updTotPoints.updateTotalPoints(total_points);
					total_points = 0;
					new WindowCharacters();
				}
			} else {
				new WindowCharacters();
			}
		}
		if (e.getSource() == ch_weapon) {
			// The user chooses a weapon for his warrior. If the battle has started, he
			// won't be able to change it
			if (ch1.getWarrior() == null) {
				JOptionPane.showMessageDialog(null, "You have to choose a warrior!");
			}
			else if (battle) {
				JOptionPane.showMessageDialog(null, "You can't change your weapon in the middle of a battle!");
			} else {
				new WindowWeapons(ch1.getWarrior());
			}
		}
		if (e.getSource() == fightButton) {
			// The fight starts and every time the user presses the button, an attack will
			// be thrown
			if (ch1.getWarrior() == null) {
				JOptionPane.showMessageDialog(null, "You have to choose a warrior!");
			} else if (ch1.getWarrior().getWeapon() == null) {
				// We control that the user has selected a weapon
				JOptionPane.showMessageDialog(null, "You have to choose a weapon!");
			} else {
				if (battle == false) {
					initialHealth = ch1.getWarrior().getHealth();
					initialOpponentHealth = ch2.getWarrior().getHealth();
					// If the battle wasn't started, we create an array where we'll put the 2
					// warriors and decide the order
					if (rankingInserted == false) {
						// We insert the ranking of the player, that will have 0 points
						DatabaseInsert insBattle = new DatabaseInsert();
						insBattle.insertRanking(ch1.getWarrior().getId());
						rankingInserted = true;
					}

					if (ch1.getWarrior().getSpeed() + ch1.getWarrior().getWeapon().getSpeed() > ch2.getWarrior()
							.getSpeed() + ch2.getWarrior().getWeapon().getSpeed()) {
						//The warrior with more speed will start the battle
						fightingWarriors[0] = ch1;
						fightingWarriors[1] = ch2;
					} else if (ch1.getWarrior().getSpeed() + ch1.getWarrior().getWeapon().getSpeed() < ch2.getWarrior()
							.getSpeed() + ch2.getWarrior().getWeapon().getSpeed()) {
						fightingWarriors[0] = ch2;
						fightingWarriors[1] = ch1;
						
					} else if (ch1.getWarrior().getAgility() > ch2.getWarrior().getAgility()) {
						//If they have the same speed, the one with more agility will start
						fightingWarriors[0] = ch1;
						fightingWarriors[1] = ch2;
					} else if (ch1.getWarrior().getAgility() < ch2.getWarrior().getAgility()) {
						fightingWarriors[0] = ch2;
						fightingWarriors[1] = ch1;
						
					} else {
						// If they have the same speed and agility, the order will be random
						int n = (int) (Math.random() * 2);
						fightingWarriors[n] = ch1;
						if (n == 0) {
							fightingWarriors[1] = ch2;
						} else {
							fightingWarriors[0] = ch2;
						}
					}
					battle = true;
				}
				// We use the variable round to decide who attacks. We use the Warrior method
				// attack
				String result = fightingWarriors[round % 2].getWarrior()
						.attack(fightingWarriors[(round + 1) % 2].getWarrior());

				// We show in the console what's happened with the attack and change the health
				// of the defender
				console.setText(console.getText() + fightingWarriors[round % 2].getWarrior().getName() + "'s turn\n"
						+ result + "\n");
				fightingWarriors[(round + 1) % 2].setHealth();

				if (ch1.getWarrior().getHealth() <= 0 | ch2.getWarrior().getHealth() <= 0) {
					// When one of the warrior's health is 0 or less, the battle ends. We'll show a
					// window to ask if the user wants to keep playing
					battle = false;
					int points = ch1.getWarrior().getHealth();

					
					// We insert the battle in the database
					round = 0;
					if (ch1.getWarrior().getHealth() <= 0) {
						// If you lose, a JOptionPane appears saying that you have lost
						ch1.getWarrior().setHealth(0);
						ch1.setHealth();
						points = 0;
						
						win = false;
						JOptionPane.showMessageDialog(null,
								"You lost the battle!\n Your final score is " + total_points + " points");
					} else {
						// If you lose, a JOptionPane appears saying that you have won
						ch2.getWarrior().setHealth(0);
						ch2.setHealth();
						win = true;
						// We update the points of the database
						total_points = total_points + points;
						DatabaseInsert updateRanking = new DatabaseInsert();
						updateRanking.updateTotalPoints(total_points);
						JOptionPane.showMessageDialog(null,
								"You won the battle!\n You have " + total_points + " points");
					}
					int injuriesCaused = initialOpponentHealth - ch2.getWarrior().getHealth();
					int injuriesSuffered = initialHealth - ch1.getWarrior().getHealth();
					//We insert the battle once it's over
					DatabaseInsert insBattle = new DatabaseInsert();
					insBattle.insertBattle(ch1.getWarrior().getId(), ch1.getWarrior().getWeapon().getId(),
							ch2.getWarrior().getId(), ch2.getWarrior().getWeapon().getId(),points,injuriesCaused
							,injuriesSuffered);
					new WindowKF();
				} 
				else {
					// Here we put the chance of a double attack using the speed of the warrior
					if (fightingWarriors[round % 2].getWarrior().getSpeed() + fightingWarriors[round % 2].getWarrior()
							.getWeapon().getSpeed() <= fightingWarriors[(round + 1) % 2].getWarrior().getSpeed()
									+ fightingWarriors[(round + 1) % 2].getWarrior().getWeapon().getSpeed()) {
						round++;
					} else {
						int number = (int) (Math.random() * 100);
						if (fightingWarriors[round % 2].getWarrior().getSpeed()
								+ fightingWarriors[round % 2].getWarrior().getWeapon().getSpeed()
								- fightingWarriors[(round + 1) % 2].getWarrior().getSpeed()
								+ fightingWarriors[(round + 1) % 2].getWarrior().getWeapon().getSpeed() > number) {
							console.setText(console.getText() + fightingWarriors[round % 2].getWarrior().getName()
									+ " will attack again because of his great speed!\n");
						} else {
							round++;
						}
					}
				}

			}
		}
		if (e.getSource() == clearConsole) {
			// Button to clear the console
			console.setText("");
		}
	}

	class WindowKF extends JFrame implements ActionListener, WindowListener {

		// Window to ask the user if he wants to keep playing
		private JPanel KF, buttons;
		private JButton yes, no;

		private JLabel title;
		private boolean closeWindow = false;;

		WindowKF() {
			// JPanel
			KF = new JPanel();
			KF.setBackground(Color.BLACK);
			buttons = new JPanel();
			buttons.setBackground(Color.BLACK);
			KF.setLayout(new BorderLayout());
			this.add(KF);
			KF.add(buttons, BorderLayout.SOUTH);

			// JLabel
			if (win) {
				title = new JLabel("Do you want to keep fighting?", SwingConstants.CENTER);
			} else {
				title = new JLabel("Do you want to play again?", SwingConstants.CENTER);
			}
			title.setFont(new Font("arial", Font.BOLD, 20));
			title.setForeground(Color.WHITE);
			KF.add(title, BorderLayout.CENTER);

			// Buttons
			yes = new JButton("Yes");
			yes.setBackground(Color.WHITE);
			no = new JButton("No");
			no.setBackground(Color.WHITE);
			buttons.add(yes);
			buttons.add(no);

			yes.addActionListener(this);
			no.addActionListener(this);
			
			Toolkit window = Toolkit.getDefaultToolkit();
			Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
			setIconImage(icon);
			
			this.setResizable(false);
			this.addWindowListener(this);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setSize(500, 200);
			this.setLocationRelativeTo(null);
			setVisible(true);
		}

		public void actionPerformed(ActionEvent e) {
			// We clear the console
			console.setText("");
			if (e.getSource() == yes) {
				closeWindow = true;
				ch2.resetStats();
				Warrior newWarrior = warriors.randomWarrior();
				newWarrior.setWeapon(wepCont_w2.getRandomWeapon(newWarrior));
				ch2.setWarrior(newWarrior);
				// If he selects yes
				if (win == true) {
					// If he has won, we reset the warriors stats and select a random warrior for
					// the panel 2
					ch1.resetStats();
					dispose();
				} else {
					// If he lost and wants to keep playing, he will have to create another user
					DatabaseInsert updateRanking = new DatabaseInsert();
					updateRanking.updateTotalPoints(total_points);
					rankingInserted = false;
					total_points = 0;
					ch1.setWarrior(null);
					dispose();
				}
			}
			if (e.getSource() == no) {
				// If he doesn't want to keep playing, we insert the total point into the
				// database and the program ends
				DatabaseInsert updateRanking = new DatabaseInsert();
				updateRanking.updateTotalPoints(total_points);
				System.exit(0);
			}

		}

		@Override
		public void windowOpened(WindowEvent e) {}

		@Override
		public void windowClosing(WindowEvent e) {}

		@Override
		public void windowClosed(WindowEvent e) {
			if (!closeWindow) {
				// If he closes the window, the program ends
				System.exit(0);
			}
		}

		@Override
		public void windowIconified(WindowEvent e) {}

		@Override
		public void windowDeiconified(WindowEvent e) {}

		@Override
		public void windowActivated(WindowEvent e) {
		}

		@Override
		public void windowDeactivated(WindowEvent e) {}
	}

}

class BackgroundButton extends JButton {
	//Personalized button where we save the url of the background the user selects
	private String url;

	public BackgroundButton() {
		super();
	}

	public BackgroundButton(ImageIcon i, String url) {
		super();
		this.setIcon(i);
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}

class WarriorButton extends JButton {
	//Personalized button where we save the id of the warrior the user selects
	private int id;

	public WarriorButton() {
		super();
	}

	public WarriorButton(ImageIcon i, int id, String name) {
		super();
		this.setIcon(i);
		this.setText(name);
		this.setHorizontalTextPosition(SwingConstants.CENTER);
		this.setVerticalTextPosition(SwingConstants.BOTTOM);
		this.id = id;
	}

	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}

}

class WeaponButton extends JButton {
	//Personalized button where we save the id of the weapon the user selects
	private int id;

	public WeaponButton() {
		super();
	}

	public WeaponButton(ImageIcon i, int id, String name) {
		super();
		this.setIcon(i);
		this.setText(name);
		this.setHorizontalTextPosition(SwingConstants.CENTER);
		this.setVerticalTextPosition(SwingConstants.BOTTOM);
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}

class GlobalRanking extends JFrame {
	// Window that shows the 5 users with more points
	private DatabaseInsert glRanking = new DatabaseInsert();
	private ArrayList<String[]> globalRanking = glRanking.globalRanking();
	private JPanel table;
	private JLabel title1, name, points, warrior;

	GlobalRanking() {
		setBackground(Color.black);
		title1 = new JLabel("GLOBAL RANKING", SwingConstants.CENTER);
		title1.setForeground(Color.black);
		title1.setBackground(Color.black);
		table = new JPanel();

		table.setLayout(new GridLayout(globalRanking.size() + 1, 3));
		table.setBackground(Color.black);
		
		name = new JLabel("NAME");
		name.setForeground(Color.yellow);
		points = new JLabel("POINTS");
		points.setForeground(Color.yellow);
		warrior = new JLabel("WARRIOR");
		warrior.setForeground(Color.yellow);
		
		table.add(name);
		table.add(points);
		table.add(warrior);

		for (String[] row : globalRanking) {
			JLabel name1 = new JLabel(row[0]);
			JLabel points1 = new JLabel(row[1]);
			JLabel warrior1 = new JLabel(row[2]);
			name1.setForeground(Color.white);
			points1.setForeground(Color.white);
			warrior1.setForeground(Color.white);
			table.add(name1);
			table.add(points1);
			table.add(warrior1);
		}
		
		Toolkit window = Toolkit.getDefaultToolkit();
		Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
		setIconImage(icon);
		
		this.add(title1, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		this.setResizable(false);

		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600, 300);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
}

class DefeatedEnemies extends JFrame {
	// Window that shows the 5 users with more defeated enemies
	private DatabaseInsert defEnemies = new DatabaseInsert();
	private ArrayList<String[]> defeatedEnemies = defEnemies.defeatedEnemies();
	private JPanel table;
	private JLabel title, name, defEn;

	DefeatedEnemies() {
		title = new JLabel("DEFEATED ENEMIES RANKING", SwingConstants.CENTER);
		title.setForeground(Color.black);
		title.setBackground(Color.white);
		
		table = new JPanel();
		table.setLayout(new GridLayout(defeatedEnemies.size() + 1, 2));
		table.setBackground(Color.black);
		
		name = new JLabel("NAME");
		name.setForeground(Color.yellow);
		defEn = new JLabel("DEFEATED ENEMIES");
		defEn.setForeground(Color.yellow);
		
		table.add(name);
		table.add(defEn);
		
		for (String[] row : defeatedEnemies) {
			JLabel name1 = new JLabel(row[0]);
			name1.setForeground(Color.white);
			JLabel defEn1 = new JLabel(row[1]);
			defEn1.setForeground(Color.white);
			table.add(name1);
			table.add(defEn1);
		}
		this.add(title, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		
		Toolkit window = Toolkit.getDefaultToolkit();
		Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
		setIconImage(icon);
		
		this.setResizable(false);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(450, 300);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

}


class MostUsedWarriors extends JFrame {
	// Window that shows the 5 most used warriors
	private DatabaseInsert mostUsedWarriors = new DatabaseInsert();
	private ArrayList<String[]> injuriesCaused = mostUsedWarriors.moreUsedWarriors();
	private JPanel table;
	private JLabel title, name, timesUsed;

	MostUsedWarriors() {
		title = new JLabel("MOST USED WARRIORS RANKING", SwingConstants.CENTER);
		title.setForeground(Color.black);
		title.setBackground(Color.white);
		table = new JPanel();
		table.setLayout(new GridLayout(injuriesCaused.size() + 1, 2));
		table.setBackground(Color.black);
		name = new JLabel("WARRIOR");
		name.setForeground(Color.yellow);
		timesUsed = new JLabel("TIMES USED");
		timesUsed.setForeground(Color.yellow);
		table.add(name);
		table.add(timesUsed);
		for (String[] row : injuriesCaused) {
			JLabel name1 = new JLabel(row[0]);
			name1.setForeground(Color.white);
			JLabel timesUsed = new JLabel(row[1]);
			timesUsed.setForeground(Color.white);
			table.add(name1);
			table.add(timesUsed);
		}
		this.add(title, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		
		Toolkit window = Toolkit.getDefaultToolkit();
		Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
		setIconImage(icon);
		
		this.setResizable(false);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600, 300);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

}

class MostUsedWeapons extends JFrame {
	// Window that shows the 5 most used weapons
	private DatabaseInsert mostUsedWeapons = new DatabaseInsert();
	private ArrayList<String[]> injuriesCaused = mostUsedWeapons.moreUsedWeapons();
	private JPanel table;
	private JLabel title, name, timesUsed;

	MostUsedWeapons() {
		title = new JLabel("MOST USED WEAPONS RANKING", SwingConstants.CENTER);
		title.setForeground(Color.black);
		title.setBackground(Color.white);
		table = new JPanel();
		table.setLayout(new GridLayout(injuriesCaused.size() + 1, 2));
		table.setBackground(Color.black);
		name = new JLabel("WEAPON");
		name.setForeground(Color.yellow);
		timesUsed = new JLabel("TIMES USED");
		timesUsed.setForeground(Color.yellow);
		table.add(name);
		table.add(timesUsed);
		for (String[] row : injuriesCaused) {
			JLabel name1 = new JLabel(row[0]);
			name1.setForeground(Color.white);
			JLabel timesUsed = new JLabel(row[1]);
			timesUsed.setForeground(Color.white);
			table.add(name1);
			table.add(timesUsed);
		}
		this.add(title, BorderLayout.NORTH);
		this.add(table, BorderLayout.CENTER);
		
		Toolkit window = Toolkit.getDefaultToolkit();
		Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
		setIconImage(icon);
		
		this.setResizable(false);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600, 300);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

}

class WindowRanking extends JFrame implements ActionListener {
	// Window with 4 buttons where the user selects what ranking he wants to see
	private JFrame myFrame;
	private JPanel myPanel;
	private JButton global, enemies, caused, suffered;

	WindowRanking() {
		myFrame = new JFrame();
		myPanel = new JPanel();
		myPanel.setLayout(new FlowLayout());
		myPanel.setBackground(Color.black);
		global = new JButton("Global Ranking");
		enemies = new JButton("Enemies Defeated");
		caused = new JButton("Most Used Warriors");
		suffered = new JButton("Most Used Weapons");
		global.addActionListener(this);
		global.setBackground(Color.white);
		enemies.addActionListener(this);
		enemies.setBackground(Color.white);
		caused.addActionListener(this);
		caused.setBackground(Color.white);
		suffered.addActionListener(this);
		suffered.setBackground(Color.white);
		myPanel.add(global);
		myPanel.add(enemies);
		myPanel.add(caused);
		myPanel.add(suffered);
		myFrame.add(myPanel);
		
		Toolkit window = Toolkit.getDefaultToolkit();
		Image icon = window.getImage("ImagenesProjecto/Extra/iconwindow0.png");
		setIconImage(icon);
		
		myFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		myFrame.setSize(700, 100);
		myFrame.setResizable(false);
		myFrame.setLocationRelativeTo(null);
		myFrame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == global) {
			new GlobalRanking();
		} else if (e.getSource() == enemies) {
			new DefeatedEnemies();
		} else if (e.getSource() == caused) {
			new MostUsedWarriors();
		} else if (e.getSource() == suffered) {
			new MostUsedWeapons();
		}
	}

}

class ImageComponent extends JPanel {
	// Panel that contains the vs image
	private BufferedImage image;

	ImageComponent(String urlFoto) {
		try {
			image = ImageIO.read(new File(urlFoto));
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.setOpaque(false);
	}

	public void paint(Graphics g) {

		Graphics2D g2d = (Graphics2D) g;
		int x = 0;
		int y = 0;
		g2d.drawImage(image.getScaledInstance(100, 125, Image.SCALE_SMOOTH), 10, 125, this);

	}

	public void setImage(String urlFoto) {
		System.out.println("establecemos en el panel la foto " + urlFoto);
		try {
			this.image = ImageIO.read(new File(urlFoto));
		} catch (IOException e) {
			e.printStackTrace();
		}
		repaint();
	}
}